<?php
/**
 * 媒资资料库 API - 配置【示例文件】
 * ==================================================================
 * ★ 程序实际读取的是同目录下的 config.php，不是本文件。
 *
 * 两种安装方式（任选其一）：
 *   1) 推荐：在宝塔「终端」里进入站点目录，执行
 *            php tools/install-cli.php
 *            按提示输入数据库信息，会自动建表并生成 config/config.php；
 *   2) 手动：把本文件复制/改名为 config.php，填上下面的数据库信息与密钥，
 *            再导入 sql/install.sql 建表。
 *
 * 为什么没有网页版安装器：
 *   挂在公网上的安装器（原 install.php）会被他人用来重装你的站点、
 *   或者从它的环境自检里读到服务器信息，所以 v1.4.0 起**彻底移除**了它，
 *   安装只能在服务器终端完成 —— /install、/setup 等路径一律返回 404。
 *
 * 为什么发布包里只有示例、没有 config.php：
 *   避免升级覆盖源码时把你的数据库口令、API key 冲掉。
 *   所以升级时也请**保留站点上的 config/config.php 不动**。
 *
 * 兼容 PHP 5.6 ~ 8.2。所有密钥都只留在服务端，对外只暴露本服务地址。
 *
 * 说明：下面的「TMDB Key / RAWG Key / 启用数据源 / 后台令牌」以及网盘类型，
 *       装好后都可在【后台 → 系统设置】里直接增删改（存在数据库 app_settings 表，
 *       优先级高于本文件；某项留空即回退读本文件的值）。所以本文件通常只需要填对 db。
 */

/* 安全守卫：本文件只应被入口（index.php / check.php / cron / CLI）引入。
   若有人直接用网址请求本文件，会返回 404 —— 见 core/Guard.php。 */
require_once __DIR__ . '/../core/Guard.php';
ml_guard_shield(__FILE__);
return [
    // 数据库（宝塔新建的 MySQL 库）
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'dbname'   => 'media_library',
        'user'     => 'media_lib',
        'pass'     => 'CHANGE_ME',      // ← 改成宝塔上该库用户的真实密码
        'charset'  => 'utf8mb4',
    ],

    // TMDB（影视/人物） https://www.themoviedb.org/settings/api 申请
    'tmdb' => [
        'api_key'   => 'YOUR_TMDB_API_KEY',
        'base'      => 'https://api.themoviedb.org/3',
        'image_base'=> 'https://image.tmdb.org/t/p/',
        'lang'      => 'zh-CN',
    ],

    // RAWG（游戏） https://rawg.io/apidocs 申请
    'rawg' => [
        'api_key'   => 'YOUR_RAWG_API_KEY',
        'base'      => 'https://api.rawg.io/api',
    ],

    // Bangumi（动漫） https://bangumi.github.io/api/
    'bangumi' => [
        'base'      => 'https://api.bgm.tv',
    ],

    // 启用的数据源适配器（新增源只需在此加一项并在 adapters/ 加对应类）
    'adapters' => ['tmdb', 'rawg', 'bangumi'],

    // 网盘类型（后台「下载链接」下拉用）**不建议写在这里**：
    //   优先级为  后台「系统设置」  >  config/pan_types.php  >  内置默认。
    //   想加网盘请用后台「系统设置」，或改 config/pan_types.php（升级包覆盖它也不会影响密钥）。

    // 采集（同步）策略 —— 0 也可作为合法值，故每项都请写全。
    //   ★ 更推荐在【后台 → 同步采集】里改：即时生效、优先级高于本文件、升级覆盖也不会丢。
    //   每一项的含义在后台那一页都有中文说明，这里只列文件兜底值。
    'sync' => [
        'limit'           => 20,     // 每个源、每次最多入库多少条（TMDB 单页 20 / RAWG 单页 40）
        'max_pages'       => 1,      // 每个源最多翻几页（翻页越多越费上游配额）
        'max_requests'    => 8,      // 单次采集的上游请求总数硬闸（防止跑太久被网关掐断）
        'window'          => 'week', // 热门榜时间窗：day（今日）| week（本周）
        'order'           => 'both', // 取值口径：hot（最热）| popular（最多人看）| both
        'min_votes'       => 0,      // 低于该投票数的条目不入库（0 = 不限，即"最多人看"的门槛）
        'dedupe'          => 'skip', // 已采集过的条目：skip（跳过，推荐）| update（刷新数据）
        'skip_same_title' => 1,      // 同名同年（跨数据源）是否也跳过：1 是 / 0 否
        'interval'        => 55,     // 两次自动同步的最小间隔（分钟），0 = 不限
        'build'           => 1,      // 同步后是否为新增条目生成静态页：1 是 / 0 否
    ],

    // 缓存策略
    'cache' => [
        'ttl_days'   => 7,    // 详情缓存有效期（天），到期前代理直接返回本地
        'stale_days' => 30,   // 超过该天数由 sync_refresh 重新拉取
    ],

    // TMDB 兼容代理是否强制校验 key（默认 false：ZBLOK 把 base URL 改成这里即可，零改动）
    'proxy' => [
        'require_key' => false,
        'proxy_key'   => '',
    ],

    // 后台管理 token（请求头 X-Admin-Token 或 ?token=）
    'admin' => [
        'token' => 'CHANGE_ADMIN_TOKEN',   // ← 改成你自己的随机字符串
    ],
];
