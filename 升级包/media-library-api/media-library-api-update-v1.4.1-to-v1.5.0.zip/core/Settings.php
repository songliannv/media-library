<?php
namespace Core;

/* 安全守卫：本文件只应被入口（index.php / check.php / cron / CLI）引入。
   若有人直接用网址请求本文件，会返回 404 —— 见 core/Guard.php。 */
require_once __DIR__ . '/Guard.php';
ml_guard_shield(__FILE__);

/* Settings 可能被 Config 在很早的阶段懒加载（此时 index.php 还没 require DB.php），
   这里自己兜住依赖，避免 PHP 5.6 下 "Class 'Core\DB' not found" 的致命错误。 */
require_once __DIR__ . '/DB.php';

/**
 * 运行时可改设置（后台「系统设置」页写入数据库 app_settings 表）
 * ==================================================================
 * 设计目标：让「后台管理令牌 / TMDB Key / RAWG Key / 启用数据源 / 网盘类型」
 * 这几项不必再改 config/config.php —— 装完后在后台点点就能增删改。
 *
 * 优先级：app_settings（后台保存）  >  config/config.php（文件兜底）
 * 空值语义：某一项为空字符串 = **不覆盖**，自动回退到 config.php 的值。
 *           所以后台「清空某项再保存」等价于「恢复成配置文件里的值」。
 *
 * 兼容 PHP 5.6 ~ 8.2（不用 ?? / 返回类型 / 标量类型提示 等 7.0+ 语法）
 */
class Settings
{
    /** 设置表名（不带库前缀，本项目的表都是裸名） */
    const TABLE = 'app_settings';

    /** 允许后台写入的键白名单（防止任意键写入） */
    public static function keys()
    {
        return array(
            'admin_token', 'tmdb_api_key', 'rawg_api_key', 'adapters', 'pan_types',
            // —— 采集（同步）参数：后台「同步采集」页可改，作用见 Core\Sync ——
            'sync_limit', 'sync_max_pages', 'sync_max_requests', 'sync_window', 'sync_order',
            'sync_min_votes', 'sync_dedupe', 'sync_skip_same_title', 'sync_interval', 'sync_build',
        );
    }

    /** 采集参数键 → sync 段子键（Config 叠加与后台渲染共用一份映射） */
    public static function syncMap()
    {
        return array(
            'sync_limit'           => 'limit',
            'sync_max_pages'       => 'max_pages',
            'sync_max_requests'    => 'max_requests',
            'sync_window'          => 'window',
            'sync_order'           => 'order',
            'sync_min_votes'       => 'min_votes',
            'sync_dedupe'          => 'dedupe',
            'sync_skip_same_title' => 'skip_same_title',
            'sync_interval'        => 'interval',
            'sync_build'           => 'build',
        );
    }

    /** 每项的元信息：类型 + 中文标题 + 说明（后台渲染与文档共用一份定义） */
    public static function schema()
    {
        return array(
            'admin_token' => array(
                'type'  => 'text',
                'label' => '后台管理令牌（admin.token）',
                'tip'   => '登录后台用。留空则沿用 config.php 里的值；改完保存后本页会用新令牌。',
            ),
            'tmdb_api_key' => array(
                'type'  => 'text',
                'label' => 'TMDB API Key（影视 / 短剧 / 电视剧，可留空）',
                'tip'   => 'https://www.themoviedb.org/settings/api 申请，免费。留空则沿用 config.php。',
            ),
            'rawg_api_key' => array(
                'type'  => 'text',
                'label' => 'RAWG API Key（游戏，可留空）',
                'tip'   => 'https://rawg.io/apidocs 免费申请。留空则沿用 config.php。',
            ),
            'adapters' => array(
                'type'  => 'list',
                'label' => '启用哪些数据源',
                'tip'   => '决定「同步热门 / 采集」会跑哪些源；至少启用一个。',
                'options' => array(
                    'tmdb'    => 'TMDB（影视 / 短剧 / 电视剧）',
                    'rawg'    => 'RAWG（游戏，需 key）',
                    'bangumi' => 'Bangumi（动漫，免 key）',
                ),
            ),
            'pan_types' => array(
                'type'  => 'list',
                'label' => '网盘类型（后台「下载链接」下拉用）',
                'tip'   => '可自由增删；无需改文件、也无需升级包。留空则沿用 config/pan_types.php。',
            ),

            /* —— 采集（同步）参数：后台「同步采集」页渲染为表单 —— */
            'sync_limit' => array(
                'type' => 'int', 'group' => 'sync', 'min' => 1, 'max' => 200, 'unit' => '条',
                'label' => '每个源、每次最多入库多少条',
                'tip'   => '把「一次同步」限制在可控范围内：既遵守各源配额，也避免站点被灌满。TMDB 单次上限 20 条/页，RAWG 单页上限 40，所以填 20~40 最合适。',
            ),
            'sync_max_pages' => array(
                'type' => 'int', 'group' => 'sync', 'min' => 1, 'max' => 5, 'unit' => '页',
                'label' => '每个源最多翻几页',
                'tip'   => '翻页越多越费上游配额（TMDB/RAWG 都按请求计费）。建议 1；想多收内容就调「每源条数」。',
            ),
            'sync_max_requests' => array(
                'type' => 'int', 'group' => 'sync', 'min' => 1, 'max' => 60, 'unit' => '次',
                'label' => '单次同步的上游请求总数硬闸',
                'tip'   => '超过这个数量的接口调用会被直接放弃，防止计划任务跑太久被网关掐断。RAWG 免费额度 20,000 次/月（约 27 次/小时），请留有余量。',
            ),
            'sync_window' => array(
                'type' => 'select', 'group' => 'sync',
                'options' => array('day' => '今日（更新快，跟热榜更紧）', 'week' => '本周（稳，噪音少）'),
                'label' => 'TMDB 热门榜的时间窗口',
                'tip'   => '对应官方 /trending/all/{day|week}。每小时跑一次建议用「今日」。',
            ),
            'sync_order' => array(
                'type' => 'select', 'group' => 'sync',
                'options' => array('hot' => '只要「最热门」', 'popular' => '只要「最多人看」', 'both' => '两者都取（推荐，自动去重）'),
                'label' => '按什么口径取内容',
                'tip'   => '最热 = TMDB trending / RAWG -added / Bangumi 当日在播；最多人看 = TMDB popular 榜 / RAWG -rating / Bangumi 排行榜。',
            ),
            'sync_min_votes' => array(
                'type' => 'int', 'group' => 'sync', 'min' => 0, 'max' => 1000000, 'unit' => '票',
                'label' => '投票数低于此值的条目不要',
                'tip'   => '这是「最多人看」的量化门槛：TMDB 用 vote_count、Bangumi 用评分人数。0 = 不限。填 100 可过滤掉冷门条目。',
            ),
            'sync_dedupe' => array(
                'type' => 'select', 'group' => 'sync',
                'options' => array('skip' => '已存在就跳过（推荐）', 'update' => '已存在则刷新数据'),
                'label' => '遇到已采集过的条目怎么办',
                'tip'   => '「跳过」最省上游配额，也符合「重复就跳过」；「刷新」会在跳过入库的同时更新评分/热度等字段。',
            ),
            'sync_skip_same_title' => array(
                'type' => 'select', 'group' => 'sync',
                'options' => array('1' => '跳过（推荐，避免站内重复内容）', '0' => '不跳过（允许不同源的同名作品各存一条）'),
                'label' => '同名同年（跨数据源）是否也跳过',
                'tip'   => '例如同一部片在 TMDB 与 Bangumi 都有：开启后只保留先采集到的那条，站内不会出现两遍。年份允许差 1 年。',
            ),
            'sync_interval' => array(
                'type' => 'int', 'group' => 'sync', 'min' => 0, 'max' => 1440, 'unit' => '分钟',
                'label' => '两次自动同步的最小间隔',
                'tip'   => '防止手动连点或计划任务撞车导致频繁请求上游。计划任务是每小时跑一次，这里填 55 即可（0 = 不限制）。',
            ),
            'sync_build' => array(
                'type' => 'select', 'group' => 'sync',
                'options' => array('1' => '是（推荐，只生成新增的那几条）', '0' => '否，稍后统一生成'),
                'label' => '同步后顺手生成新增条目的静态页',
                'tip'   => '只生成本次新入库的 /uisc/{id}.html，不会全量重建（全量重建请用后台「生成静态页」按钮）。',
            ),
        );
    }

    private static $cache    = null;   // array|null，已读出的覆盖值
    private static $ensured  = false;  // 是否已尝试建表
    private static $writable = false;  // 建表/写表是否可用

    /* ------------------------------------------------------------------ */
    /* 读                                                                 */
    /* ------------------------------------------------------------------ */

    /**
     * 读全部覆盖值（只读，不建表）。
     * 表不存在 / 数据库不可用 → 返回空数组（等于「没有后台覆盖」）。
     */
    public static function all()
    {
        if (self::$cache !== null) {
            return self::$cache;
        }
        self::$cache = array();
        if (!class_exists('PDO')) {
            return self::$cache;   // 没装 PDO 的环境不该在这里抛致命错误
        }
        try {
            $pdo  = DB::pdo();
            $rows = $pdo->query('SELECT `k`,`v` FROM `' . self::TABLE . '`')->fetchAll();
            $keys = self::keys();
            foreach ($rows as $r) {
                $k = isset($r['k']) ? (string) $r['k'] : '';
                if (in_array($k, $keys, true)) {
                    self::$cache[$k] = isset($r['v']) ? (string) $r['v'] : '';
                }
            }
        } catch (\Exception $e) {
            // 未建表 / 连不上库 / 无权限，一律视作「无覆盖」，不影响前台
            self::$cache = array();
        }
        return self::$cache;
    }

    /** 取单个覆盖值（空字符串代表「没有覆盖」） */
    public static function get($key, $default = '')
    {
        $all = self::all();
        return isset($all[$key]) ? $all[$key] : $default;
    }

    /** 该键是否被后台覆盖过（且非空） */
    public static function has($key)
    {
        $all = self::all();
        return isset($all[$key]) && $all[$key] !== '';
    }

    /* ------------------------------------------------------------------ */
    /* 写                                                                 */
    /* ------------------------------------------------------------------ */

    /** 确保设置表存在（后台保存前 / check.php 里调用），返回是否可写 */
    public static function ensureTable()
    {
        if (self::$ensured) {
            return self::$writable;
        }
        self::$ensured = true;
        try {
            DB::pdo()->exec(
                'CREATE TABLE IF NOT EXISTS `' . self::TABLE . "` (
  `k`          VARCHAR(64) NOT NULL,
  `v`          TEXT,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );
            self::$writable = true;
        } catch (\Exception $e) {
            self::$writable = false;
        }
        return self::$writable;
    }

    /**
     * 保存设置。值为空字符串 → 删除该键（回退到 config.php）。
     * 只认白名单里的键，其余忽略。
     */
    public static function set(array $kv)
    {
        if (!self::ensureTable()) {
            throw new \Exception('设置表不可写：数据库连不上，或该数据库用户没有建表权限');
        }
        $pdo  = DB::pdo();
        $keys = self::keys();
        $del  = $pdo->prepare('DELETE FROM `' . self::TABLE . '` WHERE `k` = ?');
        $ins  = $pdo->prepare('INSERT INTO `' . self::TABLE . '` (`k`,`v`,`updated_at`) VALUES (?,?,NOW())');
        $saved = 0;
        foreach ($kv as $k => $v) {
            if (!in_array($k, $keys, true)) {
                continue;
            }
            $v = is_array($v) ? self::listToStr($v) : trim((string) $v);
            $del->execute(array($k));                       // 先删后插，兼容所有 MySQL 版本
            if ($v === '') {
                continue;                                   // 留空 = 清除覆盖
            }
            $ins->execute(array($k, $v));
            $saved++;
        }
        self::$cache = null;                                // 失效缓存，让本次请求后续读到新值
        return $saved;
    }

    /** 清除指定键的覆盖（不传则清空全部），恢复为 config.php 的值 */
    public static function clear($key = '')
    {
        $keys = $key === '' ? self::keys() : array($key);
        $kv   = array();
        foreach ($keys as $k) {
            $kv[$k] = '';
        }
        return self::set($kv);
    }

    /* ------------------------------------------------------------------ */
    /* 列表值转换（逗号分隔字符串 <-> 数组）                              */
    /* ------------------------------------------------------------------ */

    /** 数组 -> 存储字符串 */
    public static function listToStr($arr)
    {
        if (is_string($arr)) {
            $arr = self::strToList($arr);
        }
        if (!is_array($arr)) {
            return '';
        }
        $out = array();
        foreach ($arr as $x) {
            $x = trim((string) $x);
            if ($x !== '' && !in_array($x, $out, true)) {
                $out[] = $x;
            }
        }
        return implode(',', $out);
    }

    /** 存储字符串 -> 数组（兼容中英文逗号 / 换行 / 顿号） */
    public static function strToList($s)
    {
        $s = str_replace(array('，', '、', '；', ';', "\r", "\n"), array(',', ',', ',', ',', ',', ','), (string) $s);
        $out = array();
        foreach (explode(',', $s) as $x) {
            $x = trim($x);
            if ($x !== '' && !in_array($x, $out, true)) {
                $out[] = $x;
            }
        }
        return $out;
    }
}
