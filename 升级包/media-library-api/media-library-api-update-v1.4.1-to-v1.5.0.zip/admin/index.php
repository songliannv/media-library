<?php
/**
 * 后台管理界面（纯前端 SPA，无需额外依赖）
 * 通过 /api/v1/admin/* 与后端交互，请求头带 X-Admin-Token。
 * 条目管理按 6 大分类（短剧/电影/电视剧/动漫/综艺/游戏）建栏目，每类可新增/编辑/删除。
 * 网盘类型来自 config/pan_types.php（可随升级包扩展），此处不写死。
 * 新增：下载链接「失效检查」——单条 / 批量检测，结果以状态标展示。
 */
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>媒资资料库 · 管理后台</title>
<style>
  :root{ --bg:#f4f5fa; --card:#fff; --line:#eceef3; --pri:#5b5bd6; --pri2:#8b5cf6; --txt:#1b1f2a; --mut:#9aa1b1;
         --ok:#0f9d63; --dead:#e5484d; --shadow:0 6px 22px rgba(27,31,42,.06); }
  *{box-sizing:border-box}
  body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--txt);-webkit-font-smoothing:antialiased}
  header{background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;padding:15px 22px;display:flex;align-items:center;gap:12px;box-shadow:0 2px 18px rgba(91,91,214,.28)}
  header h1{font-size:16px;margin:0;font-weight:700;letter-spacing:.3px}
  header .sub{font-size:12.5px;opacity:.85;margin-left:auto}
  .wrap{max-width:1200px;margin:20px auto;padding:0 16px}
  .token-bar{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 15px;margin-bottom:16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;box-shadow:var(--shadow)}
  .token-bar input{flex:1;min-width:220px;padding:9px 11px;border:1px solid var(--line);border-radius:9px;outline:none}
  .tabs{display:flex;gap:8px;margin-bottom:16px}
  .tab{padding:9px 18px;border:1px solid var(--line);background:var(--card);border-radius:22px;cursor:pointer;font-size:14px;color:var(--mut);transition:.15s}
  .tab:hover{color:var(--pri)}
  .tab.active{background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;border-color:transparent;font-weight:600;box-shadow:0 6px 16px rgba(91,91,214,.3)}
  .card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin-bottom:16px;box-shadow:var(--shadow)}
  .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
  .stat{background:linear-gradient(160deg,#f7f7ff,#f1f1fb);border:1px solid var(--line);border-radius:11px;padding:15px}
  .stat b{font-size:22px;display:block}
  .stat span{color:var(--mut);font-size:13px}
  .cats{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
  .cat{padding:7px 16px;border:1px solid var(--line);background:var(--card);border-radius:20px;cursor:pointer;font-size:14px;color:var(--mut);transition:.15s}
  .cat:hover{color:var(--pri);border-color:var(--pri)}
  .cat.active{background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;border-color:transparent;font-weight:600}
  .toolbar{display:flex;gap:10px;margin-bottom:14px;flex-wrap:wrap}
  .toolbar input,.toolbar select{padding:9px 11px;border:1px solid var(--line);border-radius:9px;outline:none}
  .toolbar input[type=text]{flex:1;min-width:200px}
  button{background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;border:0;border-radius:9px;padding:9px 15px;cursor:pointer;font-size:14px;transition:.15s}
  button:hover{filter:brightness(1.06);box-shadow:0 6px 16px rgba(91,91,214,.28)}
  button.ghost{background:#fff;color:var(--pri);border:1px solid var(--pri)}
  button.ghost:hover{background:#f5f5ff}
  button.danger{background:linear-gradient(120deg,#e5484d,#f0686c)}
  button.sm{padding:6px 11px;font-size:13px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th,td{padding:9px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:middle}
  th{color:var(--mut);font-weight:600;background:#fafbff}
  tbody tr:hover{background:#fafbff}
  .thumb{width:46px;height:66px;object-fit:cover;border-radius:7px;background:#eee}
  .pager{display:flex;gap:8px;align-items:center;justify-content:center;margin-top:12px}
  .log{font-size:13px;line-height:1.7;white-space:pre-wrap;color:#444}
  .modal{position:fixed;inset:0;background:rgba(27,31,42,.45);display:none;align-items:center;justify-content:center;padding:20px;z-index:50}
  .modal .box{background:#fff;border-radius:16px;padding:22px;width:100%;max-width:580px;max-height:88vh;overflow:auto;box-shadow:0 24px 60px rgba(0,0,0,.3)}
  .modal h3{margin-top:0}
  .modal label{display:block;font-size:13px;color:var(--mut);margin:12px 0 5px}
  .modal input,.modal textarea,.modal select{width:100%;padding:9px 11px;border:1px solid var(--line);border-radius:9px;font-size:14px;outline:none}
  .dl-row{display:flex;gap:8px;margin-bottom:8px;align-items:center}
  .dl-row .dl-st{flex:0 0 auto;min-width:56px;text-align:center}
  .dl-row .dl-type{flex:0 0 112px;width:112px}
  .dl-row .dl-url{flex:1}
  .dl-row button{flex:0 0 auto;padding:9px 12px}
  .modal textarea{min-height:74px;resize:vertical}
  .modal .grid2{display:flex;gap:12px}
  .modal .grid2>div{flex:1}
  .row{display:flex;gap:10px;justify-content:flex-end;margin-top:16px}
  .hint{color:var(--mut);font-size:12px}
  .ext-note{background:var(--bg);border-radius:9px;padding:10px 12px;margin-top:8px;font-size:13px;color:var(--mut)}
  .st{display:inline-block;font-size:11.5px;padding:2px 9px;border-radius:20px;white-space:nowrap;font-weight:600}
  .st-ok{background:#e9f9f1;color:var(--ok)}
  .st-dead{background:#feecec;color:var(--dead)}
  .st-none{background:#f0f1f5;color:var(--mut)}
  /* --- 系统设置页 --- */
  .set-sec{border-top:1px solid var(--line);padding:18px 0 10px}
  .set-sec:first-child{border-top:0;padding-top:4px}
  .set-sec h4{margin:0 0 5px;font-size:14.5px;display:flex;align-items:center;flex-wrap:wrap;gap:4px}
  .set-sec .tip{color:var(--mut);font-size:12.5px;line-height:1.7;margin-bottom:9px}
  .set-sec input[type=text]{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:9px;font-size:14px;outline:none;font-family:inherit}
  .set-sec input[type=text]:focus{border-color:var(--pri);box-shadow:0 0 0 3px rgba(91,91,214,.12)}
  .inline{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .inline input[type=text]{flex:1;min-width:180px}
  .chk{display:flex;gap:9px;align-items:center;font-size:14px;margin:9px 0;cursor:pointer}
  .chk input{width:16px;height:16px}
  .chips{display:flex;flex-wrap:wrap;gap:8px;margin:4px 0 10px;min-height:26px}
  .chip{display:inline-flex;align-items:center;gap:8px;background:#f2f2fd;border:1px solid #e4e4f8;color:#4a4aa8;border-radius:20px;padding:5px 12px;font-size:13px}
  .chip b{cursor:pointer;color:#9a9ac4;font-weight:700;font-size:15px;line-height:1}
  .chip b:hover{color:var(--dead)}
  .set-flag{font-size:11.5px;font-weight:600;border-radius:20px;padding:2px 9px}
  .set-flag.on{background:#eef0ff;color:#4a4aa8}
  .set-flag.off{background:#f0f1f5;color:var(--mut)}
  .set-msg{font-size:13px;margin-top:12px;min-height:18px;font-weight:600}
  .fileval{color:var(--mut);font-size:12px;font-family:Consolas,monospace;word-break:break-all}
  /* --- 安全防护页 --- */
  .sec-row{display:flex;gap:12px;align-items:flex-start;padding:13px 0;border-top:1px solid var(--line)}
  .sec-row:first-child{border-top:0}
  .sec-bd{flex:0 0 76px}
  .sec-badge{display:inline-block;font-size:11.5px;font-weight:700;border-radius:20px;padding:3px 10px;white-space:nowrap}
  .sec-badge.y{background:#e9f9f1;color:var(--ok)}
  .sec-badge.n{background:#fff7e6;color:#b45309}
  .sec-badge.f{background:#feecec;color:var(--dead)}
  .sec-nm{font-size:13.5px;font-weight:600}
  .sec-dt{font-size:12.5px;color:var(--mut);margin-top:3px;word-break:break-all;line-height:1.7}
</style>
</head>
<body>
<header>
  <h1>媒资资料库 · 管理后台</h1>
  <span class="sub">条目管理 / 采集同步 / 下载链接失效检查 / 系统设置 / 静态页生成</span>
</header>
<div class="wrap">
  <div class="token-bar">
    <span class="hint">管理 Token：</span>
    <input id="token" type="text" placeholder="填入 config.php 中 admin.token" />
    <button class="ghost" onclick="saveToken()">保存</button>
    <span id="tokenState" class="hint"></span>
  </div>

  <div class="tabs">
    <div class="tab active" data-tab="overview" onclick="switchTab('overview')">概览</div>
    <div class="tab" data-tab="items" onclick="switchTab('items')">条目管理</div>
    <div class="tab" data-tab="sync" onclick="switchTab('sync')">同步采集</div>
    <div class="tab" data-tab="settings" onclick="switchTab('settings')">系统设置</div>
    <div class="tab" data-tab="security" onclick="switchTab('security')">安全防护</div>
    <div class="tab" data-tab="logs" onclick="switchTab('logs')">同步日志</div>
  </div>

  <div id="tab-overview" class="tabpane">
    <div class="card"><div class="stat-grid" id="stats"></div></div>
  </div>

  <div id="tab-items" class="tabpane" style="display:none">
    <div class="card">
      <div class="cats" id="cats">
        <button class="cat active" data-cat="">全部</button>
        <button class="cat" data-cat="short">短剧</button>
        <button class="cat" data-cat="movie">电影</button>
        <button class="cat" data-cat="tv">电视剧</button>
        <button class="cat" data-cat="anime">动漫</button>
        <button class="cat" data-cat="variety">综艺</button>
        <button class="cat" data-cat="game">游戏</button>
      </div>
      <div class="toolbar">
        <input type="text" id="q" placeholder="搜索标题…" onkeydown="if(event.key==='Enter')loadItems()">
        <button onclick="loadItems()">查询</button>
        <button class="ghost" onclick="openAdd()">+ 新增项目</button>
        <button class="ghost" id="btnSyncInline" onclick="triggerSync(false, this)">同步热门</button>
        <button class="ghost" onclick="buildStatic()">生成静态页</button>
        <button class="ghost" onclick="checkAll()">检查全部链接</button>
      </div>
      <table>
        <thead><tr><th>封面</th><th>标题</th><th>分类</th><th>来源</th><th>年份</th><th>评分</th><th>下载链接</th><th>操作</th></tr></thead>
        <tbody id="itemRows"></tbody>
      </table>
      <div class="pager">
        <button class="ghost sm" onclick="pageItems(-1)">上一页</button>
        <span id="pageInfo" class="hint"></span>
        <button class="ghost sm" onclick="pageItems(1)">下一页</button>
      </div>
    </div>
  </div>

  <div id="tab-sync" class="tabpane" style="display:none">
    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">采集（同步热门）</h3>
        <span class="hint">只取各源「最热门 / 最多人看」的榜；<b>已采集过的一律跳过</b>；按各源官方要求限流，单次条数与请求数都有上限。</span>
      </div>
      <div class="row" style="justify-content:flex-start;margin-top:12px">
        <button id="btnSync" onclick="triggerSync(false, this)">▶ 立即采集</button>
        <button class="ghost" id="btnSyncForce" onclick="triggerSync(true, this)">强制采集（忽略最小间隔）</button>
        <button class="ghost" id="btnSyncDry" onclick="dryRun(this)">预演（只探测不入库）</button>
        <span id="syncState" class="hint"></span>
      </div>
      <div id="syncReport" style="margin-top:12px"></div>
    </div>

    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">采集参数</h3>
        <span class="hint">保存到数据库 <b>app_settings</b>，立即生效；<b>后台网页与每小时计划任务共用这一套参数</b>。</span>
      </div>
      <div id="syncParams" style="margin-top:12px"><div class="hint">正在加载…</div></div>
      <div class="row">
        <button class="ghost" onclick="resetSyncParams()">恢复默认</button>
        <button onclick="saveSyncParams()">保存采集参数</button>
      </div>
      <div id="syncMsg" class="set-msg"></div>
    </div>

    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">各源「官方要求」对照本次限制</h3>
        <span class="hint">下面每个数字都来自对应站点的接口文档；我们只会比它更保守，不会更激进。</span>
      </div>
      <div id="syncPlan" style="margin-top:12px"><div class="hint">正在加载…</div></div>
    </div>

    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">每小时计划任务（宝塔面板）</h3>
        <span class="hint">让服务器自己每小时采集一次；命令行脚本已加守卫，<b>用网址访问会 404</b>。</span>
      </div>
      <div id="cronBox" style="margin-top:12px"><div class="hint">正在加载…</div></div>
    </div>

    <div class="card">
      <h3 style="margin:0 0 10px;font-size:15px">最近采集记录</h3>
      <div id="syncRecent"><div class="hint">正在加载…</div></div>
    </div>
  </div>

  <div id="tab-settings" class="tabpane" style="display:none">
    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">系统设置</h3>
        <span class="hint">改动保存到数据库 <b>app_settings</b> 表并立即生效，<b>优先级高于 config/config.php</b>；留空 = 沿用 config.php 里的值。</span>
      </div>
      <div id="setBox" style="margin-top:14px"><div class="hint">正在加载…</div></div>
      <div class="row">
        <button class="ghost" onclick="resetAllSettings()">全部恢复为 config.php 的值</button>
        <button onclick="saveSettings()">保存设置</button>
      </div>
      <div id="setMsg" class="set-msg"></div>
    </div>
  </div>

  <div id="tab-logs" class="tabpane" style="display:none">
    <div class="card"><div class="log" id="logs"></div></div>
  </div>

  <div id="tab-security" class="tabpane" style="display:none">
    <div class="card">
      <div style="display:flex;align-items:baseline;gap:10px;flex-wrap:wrap">
        <h3 style="margin:0;font-size:15px">安全防护</h3>
        <span class="hint">安装器已从站点根移除；安装相关路径、敏感目录与内部 PHP 文件被直接请求时统一返回 404。</span>
      </div>
      <div id="secBox" style="margin-top:12px"><div class="hint">正在检测…</div></div>
      <div class="row" style="justify-content:flex-start">
        <button onclick="openSelfCheck()">🔍 打开环境自检报告</button>
        <button class="ghost" onclick="loadSecurity()">重新检测</button>
      </div>
      <div class="hint" style="margin-top:8px">自检报告会自动带上当前后台令牌，无需手动输入；令牌在「系统设置」里可随时更换。</div>
    </div>
  </div>
</div>

<div class="modal" id="modal">
  <div class="box">
    <h3 id="modalTitle" style="margin-top:0">编辑条目</h3>
    <label>分类（决定新增表单字段）</label>
    <select id="e_type"></select>

    <label>标题 *</label><input id="e_title">
    <label>原标题</label><input id="e_original_title">
    <div class="grid2">
      <div><label>年份</label><input id="e_year" type="number"></div>
      <div><label>评分</label><input id="e_rating" type="number" step="0.1"></div>
    </div>
    <label>类型标签（逗号分隔，如 动作,悬疑）</label><input id="e_genres" placeholder="动作, 悬疑">
    <label>海报 URL</label><input id="e_poster">
    <label>背景图 URL</label><input id="e_backdrop">
    <label>下载链接（可添加多种网盘，如 光鸭 / 夸克；直接粘贴地址，可留空）</label>
    <div id="dlRows"></div>
    <button type="button" class="ghost sm" onclick="addDlRow()">+ 添加下载链接</button>
    <label>简介</label><textarea id="e_overview"></textarea>

    <div id="extraFields"></div>

    <div class="row">
      <button class="ghost" onclick="closeModal()">取消</button>
      <button onclick="saveEdit()">保存</button>
    </div>
  </div>
</div>

<script>
// 站点根（兼容 域名根目录 与 子目录部署；去掉结尾 /admin）
// 注意：不能写成 (x || '/')，否则根目录部署时会拼出 "//api/v1/..."（协议相对，会打到别的域名）
const API = (function(){
  let p = location.pathname.replace(/\/admin(\/.*)?$/, '');
  return p.replace(/\/+$/, '');
})();
let curPage = 1, editId = null, curCat = '', SCHEMA = null, PAN_LIST = ['夸克','迅雷','光鸭','百度','UC'];
let LINK_STATUS = {}; // url => true(有效)/false(失效)

/**
 * 统一的接口调用：**永不抛异常**。
 * 以前是 fetch(...).then(r=>r.json())——一旦服务端返回的是 HTML
 * （PHP 致命错误页 / 502 / 504 网关超时），r.json() 会 reject，
 * 调用方的 await 直接中断，按钮看起来就是"点了没反应"（只在控制台留红字）。
 * 现在任何异常/非 JSON 一律转成 {success:false, error:"…"}，页面必定给出提示。
 */
async function api(path, opts={}){
  const tk = localStorage.getItem('ml_token') || '';
  opts.headers = Object.assign({'X-Admin-Token': tk, 'Content-Type':'application/json'}, opts.headers||{});
  let r;
  try {
    r = await fetch(API + path, opts);
  } catch(e) {
    return {success:false, error:'网络请求失败：'+((e&&e.message)?e.message:e)+'（检查站点能否访问、伪静态是否生效）'};
  }
  let txt = '';
  try { txt = await r.text(); } catch(e) { txt = ''; }
  let d = null;
  try { d = txt ? JSON.parse(txt) : {}; } catch(e) { d = null; }
  if(d === null || typeof d !== 'object'){
    let hint = '';
    if(r.status===502 || r.status===504) hint = '（网关超时／上游错误：本次操作耗时过长，或 PHP 报错被面板拦下）';
    else if(r.status===500) hint = '（服务器内部错误：多为 PHP 致命错误，可打开 check.php 看第 7 组语法检查）';
    else if(r.status===404) hint = '（接口不存在：站点需配置 Nginx 伪静态，见部署文档第四节）';
    else if(r.status===403) hint = '（被拒绝：管理令牌不对，或被面板安全规则拦截）';
    const peek = String(txt||'').replace(/\s+/g,' ').slice(0,180);
    return {success:false, error:'服务器返回了非 JSON 内容（HTTP '+r.status+'）'+hint+(peek?('：'+peek):''), _http:r.status};
  }
  if(d.success===undefined){ d.success = (r.status>=200 && r.status<300); }
  d._http = r.status;
  if(!d.success && !d.error){ d.error = 'HTTP '+r.status; }
  return d;
}
/** 按钮忙碌态：跑长任务时禁用按钮并显示进度，避免"点了没反应"的错觉 */
async function busy(btn, text, fn){
  if(!btn){ return fn(); }
  const old = btn.textContent, was = btn.disabled;
  btn.disabled = true; btn.textContent = text;
  try { return await fn(); }
  finally { btn.disabled = was; btn.textContent = old; }
}
function saveToken(){ localStorage.setItem('ml_token', document.getElementById('token').value); document.getElementById('tokenState').innerText='已保存'; }

async function loadSchema(){
  const d = await api('/api/v1/categories');
  if(!d.success) return;
  SCHEMA = d.data;
  PAN_LIST = (d.data && d.data.pan_types && d.data.pan_types.length) ? d.data.pan_types : PAN_LIST;
  const sel = document.getElementById('e_type');
  sel.innerHTML = '';
  for(const k in SCHEMA.labels){
    const o=document.createElement('option'); o.value=k; o.textContent=SCHEMA.labels[k]; sel.appendChild(o);
  }
}
function switchTab(t){
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active', x.dataset.tab===t));
  document.querySelectorAll('.tabpane').forEach(x=>x.style.display = (x.id==='tab-'+t)?'block':'none');
  if(t==='overview') loadStats();
  if(t==='items') loadItems();
  if(t==='sync') loadSync();
  if(t==='settings') loadSettings();
  if(t==='logs') loadLogs();
  if(t==='security') loadSecurity();
}
async function loadStats(){
  const d = await api('/api/v1/admin/stats');
  if(!d.success){ alert(d.error||'加载失败'); return; }
  const s=d.data; let h='';
  h+=`<div class="stat"><b>${s.total}</b><span>总条目</span></div>`;
  for(const k in s.by_type) h+=`<div class="stat"><b>${s.by_type[k]}</b><span>${SCHEMA?SCHEMA.labels[k]:k}</span></div>`;
  for(const k in s.by_source) h+=`<div class="stat"><b>${s.by_source[k]}</b><span>源:${k}</span></div>`;
  document.getElementById('stats').innerHTML=h;
}
// 分类切换
document.getElementById('cats').addEventListener('click', e=>{
  if(e.target.classList.contains('cat')){
    document.querySelectorAll('#cats .cat').forEach(x=>x.classList.toggle('active', x===e.target));
    curCat = e.target.dataset.cat;
    curPage = 1; loadItems();
  }
});
async function loadItems(){
  const q=document.getElementById('q').value;
  const d=await api(`/api/v1/admin/items?page=${curPage}&type=${curCat}&q=${encodeURIComponent(q)}`);
  if(!d.success){ alert(d.error||'加载失败'); return; }
  // 拉取链接状态汇总
  let map={};
  try{ const m=await api('/api/v1/admin/link_status_map'); if(m.success) map=m.data.map||{}; }catch(e){}
  let h='';
  d.data.items.forEach(it=>{
    const lb = SCHEMA ? (SCHEMA.labels[it.type]||it.type) : it.type;
    const st = linkCell(map[it.id]);
    h+=`<tr>
      <td>${it.poster?`<img class="thumb" src="${it.poster}">`:''}</td>
      <td>${esc(it.title||'')}<br><span class="hint">${(it.original_title||'')}</span></td>
      <td>${lb}</td><td>${esc(it.source||'')}</td><td>${it.year||''}</td><td>${it.rating==null?'':it.rating}</td>
      <td>${st}</td>
      <td><button class="ghost sm" onclick="checkOne(${it.id})">查</button>
          <button class="ghost sm" onclick="openEdit(${it.id})">编辑</button>
          <button class="danger sm" onclick="del(${it.id})">删</button></td></tr>`;
  });
  document.getElementById('itemRows').innerHTML=h;
  document.getElementById('pageInfo').innerText=`第 ${curPage} 页 / 共 ${d.data.total} 条`;
}
function linkCell(s){
  if(!s) return '<span class="st st-none">未检测</span>';
  const dl = s.dead||0;
  if(dl>0) return `<span class="st st-dead">✗ 失效 ${dl}</span>`;
  return '<span class="st st-ok">✓ 有效</span>';
}
function pageItems(d){ if(curPage+d<1) return; curPage+=d; loadItems(); }

// 渲染分类扩展字段
function renderExtra(type, values){
  const box=document.getElementById('extraFields'); box.innerHTML='';
  const fs = (SCHEMA && SCHEMA.extra_fields[type]) ? SCHEMA.extra_fields[type] : [];
  if(!fs.length){ box.innerHTML='<div class="ext-note">该分类暂无额外字段，想加集数/导演等可在 core/Categories.php 配置。</div>'; return; }
  let h='<div class="ext-note">'+ (SCHEMA.labels[type]||type) +'专属字段：</div>';
  fs.forEach(f=>{
    h+=`<label>${f.label}</label><input id="x_${f.k}" placeholder="${f.ph||''}" value="${(values&&values[f.k]!=null)?esc(values[f.k]):''}">`;
  });
  box.innerHTML=h;
}
function openAdd(){
  editId=0; LINK_STATUS={};
  ['e_title','e_original_title','e_year','e_rating','e_genres','e_poster','e_backdrop','e_overview']
    .forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  const sel=document.getElementById('e_type'); sel.value = curCat || 'movie';
  document.getElementById('dlRows').innerHTML='';
  addDlRow(PAN_LIST[0]||'夸克','', null);
  renderExtra(sel.value, {});
  document.getElementById('modalTitle').innerText='新增项目';
  document.getElementById('modal').style.display='flex';
}
async function openEdit(id){
  editId=id; const d=await api('/api/v1/admin/item/'+id);
  if(!d.success){ alert(d.error); return; }
  const it=d.data;
  // 链接状态映射
  LINK_STATUS={};
  (it.link_checks||[]).forEach(c=>{ LINK_STATUS[c.url] = (parseInt(c.status,10)===1); });
  document.getElementById('e_type').value=it.type||'movie';
  document.getElementById('e_title').value=it.title||'';
  document.getElementById('e_original_title').value=it.original_title||'';
  document.getElementById('e_year').value=it.year||'';
  document.getElementById('e_rating').value=it.rating==null?'':it.rating;
  try{ const gs=JSON.parse(it.genres||'[]'); document.getElementById('e_genres').value=Array.isArray(gs)?gs.join(', '):''; }catch(e){ document.getElementById('e_genres').value=''; }
  document.getElementById('e_poster').value=it.poster||'';
  document.getElementById('e_backdrop').value=it.backdrop||'';
  // 下载链接：解析 JSON 数组 [{"label","url"}] 或旧版纯文本
  const links = parseDownloads(it.download_url||'');
  document.getElementById('dlRows').innerHTML='';
  if(links.length){ links.forEach(l=>addDlRow(l.label||(PAN_LIST[0]||'夸克'), l.url||'', statusOf(l.url))); } else { addDlRow(PAN_LIST[0]||'夸克','', null); }
  document.getElementById('e_overview').value=it.overview||'';
  let extra={}; try{ extra=JSON.parse(it.extra||'{}')||{}; }catch(e){ extra={}; }
  renderExtra(it.type||'movie', extra);
  document.getElementById('modalTitle').innerText='编辑 #'+id;
  document.getElementById('modal').style.display='flex';
}
function statusOf(url){ return (url && url in LINK_STATUS) ? LINK_STATUS[url] : null; }
function closeModal(){ document.getElementById('modal').style.display='none'; }
async function saveEdit(){
  const type=document.getElementById('e_type').value;
  const genres=document.getElementById('e_genres').value.split(',').map(s=>s.trim()).filter(Boolean);
  const extra={};
  const fs=(SCHEMA&&SCHEMA.extra_fields[type])?SCHEMA.extra_fields[type]:[];
  fs.forEach(f=>{ const el=document.getElementById('x_'+f.k); if(el){ const v=el.value.trim(); if(v) extra[f.k]=v; } });
  const body={
    type,
    title:document.getElementById('e_title').value.trim(),
    original_title:document.getElementById('e_original_title').value.trim(),
    year:document.getElementById('e_year').value||null,
    rating:document.getElementById('e_rating').value||null,
    genres:JSON.stringify(genres),
    poster:document.getElementById('e_poster').value.trim(),
    backdrop:document.getElementById('e_backdrop').value.trim(),
    download_url:collectDownloads(),
    overview:document.getElementById('e_overview').value,
    extra:JSON.stringify(extra),
  };
  if(!body.title){ alert('标题必填'); return; }
  const d = editId
    ? await api('/api/v1/admin/item/'+editId,{method:'PUT',body:JSON.stringify(body)})
    : await api('/api/v1/admin/item',{method:'POST',body:JSON.stringify(body)});
  if(!d.success){ alert(d.error); return; }
  const id = editId ? editId : (d.data.id||0);
  if(id){ await api('/api/v1/admin/build',{method:'POST',body:JSON.stringify({id})}).catch(()=>{}); }
  closeModal(); loadItems();
}
async function del(id){ if(!confirm('确认删除 #'+id+' ？')) return; const d=await api('/api/v1/admin/item/'+id,{method:'DELETE'}); if(d.success) loadItems(); else alert(d.error); }
/**
 * 采集入口：网页按钮与计划任务走同一套引擎（core/Sync.php）。
 * force=true 忽略「最小间隔」；dry=true 只探测接口不入库。
 */
async function triggerSync(force, btn){
  const tk = localStorage.getItem('ml_token') || '';
  if(!tk){ alert('请先在页面顶部填入管理 Token 并点「保存」，再执行采集。'); return; }
  const st  = document.getElementById('syncState');
  const box = document.getElementById('syncReport');
  if(btn) btn.disabled = true;
  if(st)  st.textContent = (force ? '正在强制采集' : '正在采集') + '（按各源官方要求限流，可能要十几秒）…';
  if(box) box.innerHTML = '<div class="hint">正在请求上游…请勿关闭页面。</div>';
  const d = await api('/api/v1/admin/sync', {method:'POST', body: JSON.stringify({force: !!force})});
  if(btn) btn.disabled = false;
  if(st) st.textContent = '';
  if(!d.success){
    if(box) box.innerHTML = '<div class="ext-note" style="background:#feecec;color:#b91c1c">✗ 采集失败：'+esc(d.error)+'</div>';
    return;
  }
  renderSyncReport(d.data);
  loadStats(); loadItems(); loadSyncPlan(); loadSyncRecent();
}
async function dryRun(btn){
  const tk = localStorage.getItem('ml_token') || '';
  if(!tk){ alert('请先填入管理 Token 并点「保存」。'); return; }
  const box = document.getElementById('syncReport');
  if(btn) btn.disabled = true;
  const d = await api('/api/v1/admin/sync', {method:'POST', body: JSON.stringify({dry:true, force:true})});
  if(btn) btn.disabled = false;
  if(!d.success){ if(box) box.innerHTML='<div class="ext-note" style="background:#feecec;color:#b91c1c">✗ 预演失败：'+esc(d.error)+'</div>'; return; }
  renderSyncReport(d.data, true);
}
/** 把采集报告画成一张清楚的表（而不是一句 alert） */
function renderSyncReport(r, isDry){
  const box = document.getElementById('syncReport');
  if(!box || !r) return;
  let h = '';
  if(r.skipped){
    h += `<div class="ext-note" style="background:#fff7ed;color:#9a3412">⏸ 本次跳过：${esc(r.reason||'')}</div>`;
  } else if(!r.ok){
    h += `<div class="ext-note" style="background:#feecec;color:#b91c1c">✗ 失败：${esc(r.reason||'未知原因')}</div>`;
  } else {
    h += `<div class="ext-note" style="background:#ecfdf5;color:#065f46">${isDry?'🔍 预演完成（未入库）':'✓ 采集完成'}：
      抓到 <b>${r.fetched}</b> 条 → 新增 <b>${r.inserted}</b> 条，重复跳过 <b>${r.skipped_dup}</b> 条${r.skipped_low?('，低于票数门槛 '+r.skipped_low+' 条'):''}；
      上游请求 <b>${r.requests}</b> 次，静态页 <b>${r.built}</b> 个，耗时 ${((r.ms||0)/1000).toFixed(1)}s。
      ${r.reason?('<br>提示：'+esc(r.reason)):''}</div>`;
  }
  h += '<table style="margin-top:10px"><thead><tr><th>数据源</th><th>接口</th><th>抓到</th><th>新增</th><th>重复跳过</th><th>备注</th></tr></thead><tbody>';
  (r.sources||[]).forEach(s=>{
    const eps = (s.endpoints||[]);
    if(!eps.length){
      h += `<tr><td>${esc(s.label||s.source)}</td><td class="hint">—</td><td>${s.fetched||0}</td><td>${s.inserted||0}</td><td>${s.skipped_dup||0}</td><td class="hint">${esc(s.msg||'')}</td></tr>`;
    } else {
      eps.forEach((ep,i)=>{
        h += `<tr>`+
          (i===0?`<td rowspan="${eps.length}">${esc(s.label||s.source)}</td>`:'')+
          `<td class="hint">${esc(ep.path)}${ep.error?(' <span style="color:#b91c1c">✗ '+esc(ep.error)+'</span>'):''}</td>`+
          (i===0?`<td rowspan="${eps.length}">${s.fetched||0}</td><td rowspan="${eps.length}">${s.inserted||0}</td><td rowspan="${eps.length}">${s.skipped_dup||0}</td>`:'')+
          (i===0?`<td rowspan="${eps.length}" class="hint">${esc(s.msg||'')}</td>`:'')+
        `</tr>`;
      });
    }
  });
  h += '</tbody></table>';
  box.innerHTML = h;
}

/* ===== 同步采集页（参数 / 官方限制对照 / 计划任务 / 最近记录）===== */
let SYNC_PLAN = null, SYNC_META = null, SYNC_DRAFT = null;

function syncGroupKeys(){
  const keys = [];
  const m = SYNC_META || {};
  for(const k in m){ if(m[k] && m[k].group==='sync'){ keys.push(k); } }
  return keys;
}
async function loadSync(){
  await loadSyncPlan();
  await loadSyncRecent();
}
async function loadSyncPlan(){
  const pbox = document.getElementById('syncParams');
  const box  = document.getElementById('syncPlan');
  const cbox = document.getElementById('cronBox');
  if(pbox) pbox.innerHTML = '<div class="hint">正在加载…</div>';
  const [plan, set] = await Promise.all([ api('/api/v1/admin/sync_plan'), api('/api/v1/admin/settings') ]);
  if(!plan.success){ if(pbox) pbox.innerHTML='<div class="hint">'+esc(plan.error||'加载失败')+'</div>'; return; }
  SYNC_PLAN = plan.data;
  if(set.success && set.data && set.data.meta){ SYNC_META = set.data.meta; }
  renderSyncParams();
  renderSyncPlanTable();
  renderCronBox();
}
function renderSyncParams(){
  const pbox = document.getElementById('syncParams');
  if(!pbox) return;
  const m = SYNC_META || {};
  const keys = syncGroupKeys();
  if(!keys.length){
    pbox.innerHTML = '<div class="hint">未能读到参数定义（请确认站点已上传最新的 core/Settings.php）。</div>';
    return;
  }
  let h = '';
  keys.forEach(k=>{
    const mm = m[k]||{};
    const cur = (SYNC_DRAFT && SYNC_DRAFT[k]!=null) ? SYNC_DRAFT[k] : syncEffective(k, mm);
    let ctrl = '';
    if(mm.type==='select'){
      const opts = mm.options||{};
      ctrl = `<select id="sy_${k}" onchange="onSyncParamChange()">` +
        Object.keys(opts).map(o=>`<option value="${esc(o)}" ${String(o)===String(cur)?'selected':''}>${esc(opts[o])}</option>`).join('') +
      `</select>`;
    } else {
      ctrl = `<input type="number" id="sy_${k}" min="${mm.min!=null?mm.min:0}" max="${mm.max!=null?mm.max:''}" value="${esc(cur)}" onchange="onSyncParamChange()" style="width:110px">`
           + (mm.unit?`<span class="hint" style="margin-left:6px">${esc(mm.unit)}</span>`:'');
    }
    h += `<div class="set-sec">
      <h4>${esc(mm.label||k)}</h4>
      <div class="tip">${esc(mm.tip||'')}</div>
      <div class="inline">${ctrl}</div>
    </div>`;
  });
  pbox.innerHTML = h;
}
/** 取某个采集参数的当前生效值（plan.params 用的是 sync 段子键） */
function syncEffective(settingKey, meta){
  const map = {sync_limit:'limit',sync_max_pages:'max_pages',sync_max_requests:'max_requests',
    sync_window:'window',sync_order:'order',sync_min_votes:'min_votes',sync_dedupe:'dedupe',
    sync_skip_same_title:'skip_same_title',sync_interval:'interval',sync_build:'build'};
  const child = map[settingKey];
  const p = (SYNC_PLAN && SYNC_PLAN.params) ? SYNC_PLAN.params : {};
  if(child && p[child]!=null) return String(p[child]);
  return '';
}
function onSyncParamChange(){ collectSyncDraft(); }
function collectSyncDraft(){
  const d = {};
  syncGroupKeys().forEach(k=>{ const el=document.getElementById('sy_'+k); if(el) d[k]=el.value; });
  SYNC_DRAFT = d;
}
function renderSyncPlanTable(){
  const box = document.getElementById('syncPlan');
  if(!box || !SYNC_PLAN) return;
  const p = SYNC_PLAN.params||{};
  let h = `<div class="hint" style="margin-bottom:8px">
    本次口径：<b>${p.order==='hot'?'只要最热':(p.order==='popular'?'只要最多人看':'最热 + 最多人看（自动去重）')}</b>
    · 时间窗 <b>${p.window==='day'?'今日':'本周'}</b>
    · 每源最多 <b>${p.limit}</b> 条
    · 单次请求总上限 <b>${p.max_requests}</b> 次
    · 实际将发出 <b>${SYNC_PLAN.requests}</b> 次请求
    · 最小间隔 <b>${p.interval}</b> 分钟
    ${SYNC_PLAN.minutes_since==null ? '（尚未采集过）' : ('（距上次 '+SYNC_PLAN.minutes_since+' 分钟）')}
  </div>`;
  h += '<table><thead><tr><th>数据源</th><th>本次要打的接口（最热 / 最多人看）</th><th>官方限制与我们自设的上限</th><th>本次条数</th><th>请求间隔</th></tr></thead><tbody>';
  (SYNC_PLAN.sources||[]).forEach(s=>{
    const eps = (s.endpoints||[]).map(e=>`<div style="font-family:Consolas,monospace;font-size:12px">${esc(e.path)}</div><div class="hint" style="margin-bottom:4px">${esc(e.label)}</div>`).join('');
    h += `<tr>
      <td><b>${esc(s.label)}</b><div class="hint"><a href="${esc(s.docs)}" target="_blank" rel="noopener" style="color:inherit">接口文档</a></div></td>
      <td>${eps||'<span class="hint">—</span>'}</td>
      <td><div class="hint" style="line-height:1.8">${esc(s.quota)}<br>单页上限：${s.page_size>0?s.page_size:'—'} 条 · 本系统每源上限：<b>${s.limit}</b> 条</div></td>
      <td>${s.limit} 条</td>
      <td>${s.delay_ms} ms / 请求</td>
    </tr>`;
  });
  h += '</tbody></table>';
  h += `<div class="hint" style="margin-top:8px">说明：<b>重复就跳过</b> —— 同源同 ID 已存在直接跳过${p.skip_same_title?('；同名同年（跨源）也跳过'):''}
    ；${p.dedupe==='update'?'已存在的条目会刷新评分/热度字段':'不刷新已存在条目的数据'}。
    低于 <b>${p.min_votes}</b> 票的条目不入库。</div>`;
  box.innerHTML = h;
}
function renderCronBox(){
  const box = document.getElementById('cronBox');
  if(!box || !SYNC_PLAN) return;
  const cmd = SYNC_PLAN.cron_cmd || 'php /www/wwwroot/你的站点/cron/sync_hourly.php';
  let h = `<div class="inline">
      <input id="cronCmd" type="text" readonly value="${esc(cmd)}" style="min-width:420px">
      <button type="button" class="ghost" onclick="copyCron()">复制命令</button>
    </div>
    <ol class="hint" style="margin:10px 0 0 18px;line-height:2">
      <li>宝塔面板 → 左侧「<b>计划任务</b>」→ 添加任务</li>
      <li>任务类型选「<b>Shell 脚本</b>」，任务名称如「媒资库-每小时采集」</li>
      <li>执行周期选「<b>N 小时 → 1 小时</b>」（或「每小时」）</li>
      <li>脚本内容填上面这条命令 → 保存；建议先点一次「执行」看输出是否正常</li>
    </ol>
    <div class="hint" style="margin-top:8px">
      命令里的 php 建议用绝对路径（本机当前检测到：<code>${esc(SYNC_PLAN.php_bin||'php')}</code>），
      这样计划任务不会因为 PATH 不同而找不到命令。<br>
      脚本已做三重限制：① 与上次同步间隔不足 <b>${(SYNC_PLAN.params||{}).interval||55}</b> 分钟会自己跳过（防重复触发）；
      ② 同一时刻只允许一个采集在跑（进程锁）；③ 单次请求总数不超过 <b>${(SYNC_PLAN.params||{}).max_requests||8}</b> 次。
    </div>`;
  box.innerHTML = h;
}
function copyCron(){
  const el = document.getElementById('cronCmd');
  if(!el) return;
  el.removeAttribute('readonly'); el.select(); el.setSelectionRange(0, 9999);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch(e) { ok = false; }
  el.setAttribute('readonly','readonly');
  if(!ok && navigator.clipboard){ navigator.clipboard.writeText(el.value); ok = true; }
  const m = document.getElementById('syncMsg');
  if(m){ m.style.color = ok ? 'var(--ok)' : 'var(--dead)'; m.innerText = ok ? '✓ 命令已复制到剪贴板' : '复制失败，请手动选中复制'; }
}
async function loadSyncRecent(){
  const box = document.getElementById('syncRecent');
  if(!box || !SYNC_PLAN) return;
  const rs = SYNC_PLAN.recent || [];
  if(!rs.length){ box.innerHTML = '<div class="hint">还没有采集记录。点上面的「立即采集」或配好计划任务后就会出现在这里。</div>'; return; }
  let h = '<table><thead><tr><th>时间</th><th>触发方式</th><th>新增</th><th>结果</th><th>各源</th></tr></thead><tbody>';
  rs.forEach(r=>{
    const srcs = (r.sources||[]).map(s=>`${esc(s.source)}:${s.inserted}/跳过${s.skipped_dup}`).join(' · ');
    const kind = r.task==='sync:hourly' ? '计划任务' : (r.task==='sync:manual' ? '后台手动' : esc(r.task));
    h += `<tr>
      <td class="hint">${esc(r.created_at)}</td>
      <td>${kind}</td>
      <td>${r.items}</td>
      <td>${r.ok?'<span class="st st-ok">✓</span>':'<span class="st st-dead">✗</span>'}<span class="hint"> ${esc(String(r.reason||'').slice(0,60))}</span></td>
      <td class="hint">${srcs||'—'}</td>
    </tr>`;
  });
  h += '</tbody></table>';
  box.innerHTML = h;
}
async function saveSyncParams(){
  collectSyncDraft();
  const body = Object.assign({}, SYNC_DRAFT||{});
  const msg = document.getElementById('syncMsg');
  msg.style.color = 'var(--mut)'; msg.innerText = '保存中…';
  const d = await api('/api/v1/admin/settings', {method:'POST', body: JSON.stringify(body)});
  if(!d.success){ msg.style.color='var(--dead)'; msg.innerText = d.error||'保存失败'; return; }
  msg.style.color = 'var(--ok)'; msg.innerText = '✓ 已保存，网页采集与每小时计划任务都已按新参数执行';
  SYNC_DRAFT = null;
  await loadSyncPlan();
}
async function resetSyncParams(){
  if(!confirm('把采集参数恢复为默认（每源 20 条 / 今日 / 最热+最多人看 / 最小间隔 55 分钟…）？')) return;
  const body = {};
  syncGroupKeys().forEach(k=>{ body[k] = ''; });
  const msg = document.getElementById('syncMsg');
  const d = await api('/api/v1/admin/settings', {method:'POST', body: JSON.stringify(body)});
  if(!d.success){ msg.style.color='var(--dead)'; msg.innerText = d.error||'操作失败'; return; }
  msg.style.color='var(--ok)'; msg.innerText='✓ 已恢复默认';
  SYNC_DRAFT = null;
  await loadSyncPlan();
}
async function buildStatic(){ const d=await api('/api/v1/admin/build',{method:'POST'}); alert(d.success?('已生成 '+d.data.built+' 个静态页'):(d.error||'失败')); }
async function loadLogs(){ const d=await api('/api/v1/admin/sync_log'); if(!d.success){alert(d.error);return;} document.getElementById('logs').innerText=JSON.stringify(d.data.items,null,2); }
function esc(s){ return (s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

// ===== 下载链接（多条网盘，类型来自 config/pan_types.php，可升级扩展）=====
function panOptions(list, sel){
  list = (list && list.length) ? list : PAN_LIST;
  let h=''; list.forEach(t=>{ h+=`<option value="${esc(t)}" ${t===sel?'selected':''}>${esc(t)}</option>`; }); return h;
}
function pill(ok){
  if(ok===true)  return '<span class="st st-ok">✓ 有效</span>';
  if(ok===false) return '<span class="st st-dead">✗ 失效</span>';
  return '<span class="st st-none">未检测</span>';
}
function addDlRow(label, url='', status=null){
  label = label || (PAN_LIST[0]||'夸克');
  const wrap=document.getElementById('dlRows');
  const row=document.createElement('div'); row.className='dl-row';
  row.innerHTML=`<span class="dl-st">${pill(status)}</span>`
    +`<select class="dl-type">${panOptions(PAN_LIST, label)}</select>`
    +`<input class="dl-url" placeholder="粘贴链接，如 https://... 或 ed2k://..." value="${esc(url)}">`
    +`<button type="button" class="ghost" onclick="this.parentNode.remove()">删</button>`;
  wrap.appendChild(row);
}
function collectDownloads(){
  const rows=document.querySelectorAll('#dlRows .dl-row');
  const links=[];
  rows.forEach(r=>{ const url=r.querySelector('.dl-url').value.trim(); if(url) links.push({label:r.querySelector('.dl-type').value, url}); });
  return JSON.stringify(links);
}
function parseDownloads(raw){
  raw=(raw||'').trim(); if(!raw) return [];
  if(raw[0]==='['){ try{ const a=JSON.parse(raw); if(Array.isArray(a)) return a.map(e=> e&&typeof e==='object'? {label:e.label||'下载',url:e.url||''} : {label:'下载',url:String(e)}); }catch(e){} }
  return raw.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).map(u=>({label:'下载',url:u}));
}

// ===== 链接失效检查 =====
async function checkOne(id){
  const btns=document.querySelectorAll('#itemRows button'); btns.forEach(b=>b.disabled=true);
  const d=await api('/api/v1/admin/check_links',{method:'POST',body:JSON.stringify({id})});
  btns.forEach(b=>b.disabled=false);
  if(!d.success){ alert(d.error||'检查失败'); return; }
  const rs=d.data.results||[]; const dead=rs.filter(r=>!r.ok).length;
  alert('检测完成：共 '+rs.length+' 条，有效 '+(rs.length-dead)+' 条，失效 '+dead+' 条');
  loadItems();
}
async function checkAll(){
  if(!confirm('将逐个检测所有已填写下载链接的条目，可能耗时较久，确定继续？')) return;
  let remaining=1, round=0, ok=0, dead=0;
  while(remaining>0 && round<40){
    round++;
    const d=await api('/api/v1/admin/check_links',{method:'POST',body:JSON.stringify({limit:40})});
    if(!d.success){ alert(d.error||'检查失败'); break; }
    ok+=d.data.ok||0; dead+=d.data.dead||0; remaining=d.data.remaining||0;
    if(remaining===0 || (d.data.checked||0)===0) break; // 无进展则停止，避免空转
  }
  alert('全部检测完成：有效 '+ok+' 条，失效 '+dead+' 条');
  loadItems();
}

// ===== 系统设置（令牌 / API Key / 数据源 / 网盘类型）=====
let SET = null;        // 后端返回的设置视图
let PAN_DRAFT = [];    // 网盘类型草稿（保存时才提交）
let TXT_DRAFT = null;  // 编辑中的文本值（重绘页面时保留，避免刚打的字被清空）
let AD_DRAFT  = null;  // 编辑中的数据源勾选

const TXT_KEYS = ['admin_token','tmdb_api_key','rawg_api_key'];
const AD_KEYS  = ['tmdb','rawg','bangumi'];

function mask(s){
  s = String(s||'');
  if(!s) return '（未填写）';
  if(s.length<=10) return s.slice(0,2)+'•••';
  return s.slice(0,4)+'••••'+s.slice(-4);
}
function flag(override){
  return override ? '<span class="set-flag on">已在后台覆盖</span>'
                  : '<span class="set-flag off">来自 config.php</span>';
}
/** 把当前表单里的输入收进草稿（重绘前调用） */
function collectDraft(){
  const t = {};
  TXT_KEYS.forEach(k=>{ const el=document.getElementById('s_'+k); if(el) t[k]=el.value; });
  TXT_DRAFT = t;
  const a = [];
  AD_KEYS.forEach(k=>{ const el=document.getElementById('a_'+k); if(el&&el.checked) a.push(k); });
  AD_DRAFT = a;
}
async function loadSettings(){
  const box = document.getElementById('setBox');
  const d = await api('/api/v1/admin/settings');
  if(!d.success){ box.innerHTML='<div class="hint">'+esc(d.error||'加载失败')+'</div>'; return; }
  SET = d.data;
  PAN_DRAFT = (SET.items.pan_types.value||[]).slice();
  TXT_DRAFT = null; AD_DRAFT = null;
  renderSettings();
  const m=document.getElementById('setMsg'); m.innerText=''; m.style.color='';
}
function renderSettings(){
  const m = SET.meta, it = SET.items;
  let h='';

  if(SET.table_ok === false){
    h += `<div class="ext-note" style="background:#fff7ed;color:#9a3412">⚠️ 设置表 <b>${esc(SET.table||'app_settings')}</b> 创建失败：当前数据库用户可能没有建表权限。
      请到宝塔 → 数据库 → 该库的用户 → 权限勾选「所有权限」，或手动导入 <b>sql/migrate_settings.sql</b> 后重试。</div>`;
  }

  // 文本项：后台令牌 / TMDB Key / RAWG Key
  TXT_KEYS.forEach(k=>{
    const mm = m[k]||{}, ii = it[k]||{};
    const val = (TXT_DRAFT && TXT_DRAFT[k]!=null) ? TXT_DRAFT[k] : ii.value;
    const kind = (k==='tmdb_api_key') ? 'tmdb' : (k==='rawg_api_key' ? 'rawg' : '');
    h += `<div class="set-sec">
      <h4>${esc(mm.label||k)} ${flag(ii.override)}</h4>
      <div class="tip">${esc(mm.tip||'')}</div>
      <div class="inline">
        <input type="text" id="s_${k}" value="${esc(val)}" placeholder="${esc(ii.file)}">
        ${k==='admin_token' ? '<button type="button" class="ghost" onclick="genToken()">随机生成</button>' : ''}
        ${kind ? `<button type="button" class="ghost" onclick="testKey('${kind}')">测试连通</button>` : ''}
      </div>
      <div class="fileval">config.php 里的值：${esc(mask(ii.file))}</div>
    </div>`;
  });

  // 数据源开关
  const ma = m.adapters||{}, ia = it.adapters||{};
  const cur = AD_DRAFT ? AD_DRAFT : (ia.value||[]);
  h += `<div class="set-sec"><h4>${esc(ma.label)} ${flag(ia.override)}</h4>
    <div class="tip">${esc(ma.tip||'')}</div>`;
  const opts = ma.options||{};
  for(const k in opts){
    const on = cur.indexOf(k)>=0;
    h += `<label class="chk"><input type="checkbox" id="a_${k}" value="${esc(k)}" ${on?'checked':''}>${esc(opts[k])}</label>`;
  }
  h += `<div class="fileval">config.php 里的值：${esc((ia.file||[]).join(' / ')||'（空）')}</div></div>`;

  // 网盘类型（chip 增删）
  const mp = m.pan_types||{}, ip = it.pan_types||{};
  const chips = PAN_DRAFT.length
    ? PAN_DRAFT.map((t,i)=>`<span class="chip">${esc(t)}<b title="删除" onclick="rmPan(${i})">×</b></span>`).join('')
    : '<span class="hint">（暂无，点下面「添加」新增）</span>';
  h += `<div class="set-sec"><h4>${esc(mp.label)} ${flag(ip.override)}</h4>
    <div class="tip">${esc(mp.tip||'')}</div>
    <div class="chips" id="panChips">${chips}</div>
    <div class="inline">
      <input type="text" id="s_panNew" placeholder="输入网盘名后回车，如 123网盘" onkeydown="if(event.key==='Enter'){event.preventDefault();addPan();}">
      <button type="button" class="ghost" onclick="addPan()">添加</button>
      <button type="button" class="ghost" onclick="setPanDefault()">恢复默认</button>
    </div>
    <div class="fileval">当前生效：${esc((ip.value||[]).join(' / ')||'（空）')}　·　config/pan_types.php 里：${esc((ip.file||[]).join(' / ')||'（无该文件）')}</div>
  </div>`;

  document.getElementById('setBox').innerHTML = h;
}
function genToken(){
  const a = new Uint8Array(12);
  (window.crypto || window.msCrypto).getRandomValues(a);
  collectDraft();
  TXT_DRAFT['admin_token'] = Array.prototype.map.call(a, x=>('0'+x.toString(16)).slice(-2)).join('');
  renderSettings();
  const m=document.getElementById('setMsg'); m.style.color='var(--mut)';
  m.innerText='已生成新令牌，记得点「保存设置」';
}
function addPan(){
  const el = document.getElementById('s_panNew');
  let v = (el.value||'').trim().replace(/[,，、;；]+/g,' ').trim();
  if(!v) return;
  if(PAN_DRAFT.indexOf(v)>=0){ alert('「'+v+'」已存在'); el.value=''; return; }
  collectDraft();                 // 先保住已输入的令牌/Key
  PAN_DRAFT.push(v);
  renderSettings();
  const box=document.getElementById('s_panNew'); if(box){ box.value=''; box.focus(); }
}
function rmPan(i){ collectDraft(); PAN_DRAFT.splice(i,1); renderSettings(); }
function setPanDefault(){ collectDraft(); PAN_DRAFT = ['夸克','迅雷','光鸭','百度','UC']; renderSettings(); }
async function saveSettings(){
  const msg = document.getElementById('setMsg');
  collectDraft();
  const body = {
    admin_token:  (TXT_DRAFT['admin_token']||'').trim(),
    tmdb_api_key: (TXT_DRAFT['tmdb_api_key']||'').trim(),
    rawg_api_key: (TXT_DRAFT['rawg_api_key']||'').trim(),
    adapters: (AD_DRAFT||[]).slice(),
    pan_types: PAN_DRAFT.slice()
  };
  msg.style.color='var(--mut)'; msg.innerText='保存中…';
  const d = await api('/api/v1/admin/settings',{method:'POST',body:JSON.stringify(body)});
  if(!d.success){ msg.style.color='var(--dead)'; msg.innerText=d.error||'保存失败'; return; }
  if(d.data.token){ localStorage.setItem('ml_token', d.data.token); document.getElementById('token').value=d.data.token; }
  SET.items = d.data.items || SET.items;
  PAN_DRAFT = (SET.items.pan_types.value||[]).slice();
  TXT_DRAFT = null; AD_DRAFT = null;
  msg.style.color='var(--ok)'; msg.innerText='✓ 已保存并生效';
  renderSettings();
  loadSchema();   // 网盘类型可能变了，刷新「下载链接」下拉
}
async function resetAllSettings(){
  if(!confirm('把所有设置恢复为 config/config.php 里的值？（不影响条目数据）')) return;
  const msg = document.getElementById('setMsg');
  const d = await api('/api/v1/admin/settings_reset',{method:'POST',body:JSON.stringify({all:1})});
  if(!d.success){ msg.style.color='var(--dead)'; msg.innerText=d.error||'操作失败'; return; }
  SET.items = d.data.items || SET.items;
  PAN_DRAFT = (SET.items.pan_types.value||[]).slice();
  TXT_DRAFT = null; AD_DRAFT = null;
  msg.style.color='var(--ok)'; msg.innerText='✓ 已恢复为 config.php 里的值';
  renderSettings(); loadSchema();
}
async function testKey(kind){
  const id = (kind==='tmdb') ? 's_tmdb_api_key' : 's_rawg_api_key';
  const msg = document.getElementById('setMsg');
  const el  = document.getElementById(id);
  msg.style.color='var(--mut)'; msg.innerText='正在测试 '+kind.toUpperCase()+' …';
  const d = await api('/api/v1/admin/settings_test',{method:'POST',body:JSON.stringify({kind, key: el ? el.value.trim() : ''})});
  if(!d.success){ msg.style.color='var(--dead)'; msg.innerText=d.error||'测试失败'; return; }
  const r = d.data;
  msg.style.color = r.ok ? 'var(--ok)' : 'var(--dead)';
  msg.innerText = (r.ok?'✓ 可用':'✗ 不可用') + ' · HTTP ' + (r.code||0) + (r.msg ? (' · '+r.msg) : '');
}

// ===== 安全防护（安装器已下线 / 敏感文件暴露面）=====
function secBadge(ok, level){
  if(level==='fail') return '<span class="sec-badge f">需处理</span>';
  if(level==='info') return '<span class="sec-badge n">提示</span>';
  return ok ? '<span class="sec-badge y">已防护</span>' : '<span class="sec-badge n">待处理</span>';
}
function secRow(ok, name, detail, hint, level){
  return `<div class="sec-row">
    <div class="sec-bd">${secBadge(ok, level)}</div>
    <div style="flex:1">
      <div class="sec-nm">${esc(name)}</div>
      <div class="sec-dt">${esc(detail||'')}</div>
      ${hint?`<div class="hint" style="display:block;margin-top:5px">${esc(hint)}</div>`:''}
    </div></div>`;
}
async function loadSecurity(){
  const box = document.getElementById('secBox');
  box.innerHTML = '<div class="hint">正在检测…</div>';
  const d = await api('/api/v1/admin/security');
  if(!d.success){ box.innerHTML = '<div class="hint">'+esc(d.error||'加载失败')+'</div>'; return; }
  const g = d.data.guard || {};
  let h = '';
  h += `<div class="ext-note" style="background:#ecfdf5;color:#065f46">
    🔒 本站已<b>移除网页版安装器</b>：安装相关路径、敏感目录、内部 PHP 文件被直接请求时统一返回 404。
    不会再出现"未填数据库就提示装好"，别人也无法从网址重装本站或读取环境信息。</div>`;

  h += secRow(!!g.install_removed, '网页版安装器 install.php',
      g.install_removed ? '已从站点根移除（公网无法重装）' : '仍存在于站点根目录，任何人都能重装本站！',
      g.install_removed ? '' : '立刻删除站点根目录的 install.php',
      g.install_removed ? '' : 'fail');

  if(g.install_ghosts && g.install_ghosts.length){
    h += secRow(false, '安装类残留文件', g.install_ghosts.join('、'), '建议一并删除', 'fail');
  }

  h += secRow(!!g.cli_installer, '命令行安装器 tools/install-cli.php',
      g.cli_installer ? '就位（仅命令行可执行，公网访问 404）' : '未上传（不影响运行，重装 / 迁移时才需要）',
      g.cli_installer ? '重装或换服务器时，在宝塔终端执行：php tools/install-cli.php' : '需要时从发布包上传 tools/ 目录',
      g.cli_installer ? '' : 'info');

  h += secRow(!!g.lock, '安装锁 config/install.lock',
      g.lock ? '存在（已标记安装完成）' : '不存在（站点能正常访问可忽略）', '');

  const dg = g.dir_guards || {}; const miss = [];
  for(const k in dg){ if(!dg[k]) miss.push(k); }
  h += secRow(miss.length===0, '敏感目录拒访文件',
      miss.length===0 ? 'config / sql / core / adapters / cron / tools 均已放置拒访 index.php'
                      : ('缺少：'+miss.join('、')),
      miss.length===0 ? '' : '从发布包对应目录补传 index.php');

  const sm = g.shield_missing || [];
  h += secRow(sm.length===0, '内部 PHP 文件反直接访问守卫',
      sm.length===0 ? ((g.shield_total||0)+' 个内部文件均已带守卫（直接用网址请求会返回 404）')
                    : ('未加守卫：'+sm.slice(0,6).join('、')),
      sm.length===0 ? '' : '用发布包覆盖对应文件即可');

  h += secRow(!!g.htaccess, '.htaccess（Apache 用）',
      g.htaccess ? '存在（Apache 自动生效；Nginx 请用宝塔伪静态规则）' : '不存在（Nginx 环境无需本文件）',
      '', g.htaccess ? '' : 'info');

  box.innerHTML = h;
}
function openSelfCheck(){
  const tk = localStorage.getItem('ml_token') || '';
  window.open(API + '/check.php?token=' + encodeURIComponent(tk), '_blank');
}

( async function(){ const t=localStorage.getItem('ml_token'); if(t) document.getElementById('token').value=t; await loadSchema(); } )();
</script>
</body>
</html>
