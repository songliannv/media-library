# 增量升级包 · media-library-api v1.5.0 → v1.6.0

> 只含**变化文件**。解压后把里面内容**覆盖**到站点根（保持目录结构）即可，**不需要执行 SQL**。
> 升级前建议先备份站点（至少备份 `config/config.php` 与数据库）。

## 变化清单

| 类型 | 数量 | 文件 |
|---|---|---|
| 新增 | 3 | `core/PanSou.php`、`core/Site.php`、`sql/migrate_site_seo.sql` |
| 修改 | 13 | `DEPLOY.md`、`admin/index.php`、`api/unified.php`、`check.php`、`config/config.sample.php`、`core/Config.php`、`core/Guard.php`、`core/Settings.php`、`core/Sync.php`、`core/Views.php`、`home.php`、`index.php`、`tools/install-cli.php` |
| 删除 | 0 | 无 |

## 覆盖后建议

1. 打开 `check.php?token=你的后台令牌`，看**第 10 组「站点设置 / SEO / 网盘接口」**是否全绿；
2. 进 **后台 →「站点设置」**，按需填基础设置 / SEO / 跳转扫码 / 网盘账号 / PanSou 接口；
3. 若要用「采集后自动补网盘下载地址」，先在「接口配置」里启用 PanSou 并点「测试连接」。

## v1.6.0 新功能

- 后台「站点设置」5 个二级页：基础设置 / SEO / 扫描+跳转 / 网盘链接 / 接口配置
- 前台接入 LOGO、可隐藏站点名、宣传语、顶部导航、经典·简约双模板、榜单有图无图、首页最新更新、页脚三段
- 动态 `/robots.txt` 与 `/sitemap.xml`
- PC 端「跳转 + 扫码」三模式（含手机端策略与降级规则）
- PanSou 网盘搜索对接 + 采集后自动补网盘下载地址（相似度打分 + 按网盘去重 + 待确认队列）
- check.php 新增第 10 组自检

## 兼容性

- 仍为 **PHP 5.6 ~ 8.2 全兼容**；
- **不需要执行任何 SQL**（无字段变更；PanSou 两张表自动创建）；
- 所有新设置项默认为空 → 前台走内置默认，**升级后不改设置，站点外观与升级前一致**。
