<?php
namespace Core;

/* 安全守卫：本文件只应被入口（index.php / check.php / cron / CLI）引入。
   若有人直接用网址请求本文件，会返回 404 —— 见 core/Guard.php。 */
require_once __DIR__ . '/Guard.php';
ml_guard_shield(__FILE__);

/* 站点设置（站点名 / LOGO / SEO / 页脚）与分类标签：让本文件也能被
   StaticGen / cron 单独引入，不依赖 index.php 的加载顺序。 */
require_once __DIR__ . '/Categories.php';
require_once __DIR__ . '/Site.php';
require_once __DIR__ . '/Settings.php';

/**
 * 视图层：主页/内页共用的 CSS + 卡片 + 内页 HTML 渲染。
 * 设计参考主流影视/资源站：干净卡片列表 + 条目内页 hero。
 * 内页为「自包含静态 HTML」：CSS 内联，图片走 CDN。
 *
 * 说明：API 调用次数属于内部指标，仅后台可见；前台只展示评分 / 年份 / 点击。
 *       下载区仅在填写了链接时才渲染，未填写则整块隐藏。
 */
class Views
{
    /** 类型中文标签（统一走 Categories） */
    public static function typeLabel($t)
    {
        return Categories::label($t);
    }

    public static function esc($s)
    {
        return htmlspecialchars((string) ((isset($s) ? $s : '')), ENT_QUOTES, 'UTF-8');
    }

    /**
     * 顶栏：LOGO + 站点名（可在后台隐藏）+ 宣传语，右侧由调用方传入。
     * 站点信息全部来自后台「基础设置」页。
     */
    public static function topbarHtml($right = '')
    {
        $info = Site::info();
        $name = self::esc($info['name']);

        $logo = '';
        if ($info['logo'] !== '') {
            $logo = '<img class="logo" src="' . self::esc(Site::asset($info['logo'])) . '" alt="' . $name . '">';
        } else {
            $logo = '<span class="dot"></span>';
        }
        // 隐藏名称只在「有 LOGO」时才真正隐藏，否则顶栏会空白
        $showName = (!$info['name_hide']) || $info['logo'] === '';
        $nameHtml = $showName ? '<b class="sname">' . $name . '</b>' : '';

        $slogan = '';
        if ($info['slogan'] !== '') {
            $slogan = '<span class="slogan">' . self::esc($info['slogan']) . '</span>';
        }
        return '<header class="topbar"><div class="in">'
             . '<a class="brand" href="/">' . $logo . $nameHtml . $slogan . '</a>'
             . $right
             . '</div>' . self::navHtml() . '</header>';
    }

    /**
     * 顶部导航。
     * 显示哪些入口由后台「站点设置 → 扫描+跳转 → 顶部导航显示」勾选决定；
     * 「顶部其他外链」支持一行一个「文字|网址」。
     * 未配置时默认「首页 / 最新更新」，保证顶栏不会空掉。
     */
    public static function navHtml()
    {
        $items = array(
            'home'    => array('首页',     '/'),
            'all'     => array('全网榜单', '/?sort=api_calls'),
            'top'     => array('Top250',   '/?sort=rating'),
            'game'    => array('游戏排行', '/?type=game&sort=rating'),
            'latest'  => array('最新更新', '/?sort=updated_at'),
            'contact' => array('联系我们', '/#contact'),
        );
        $on = Settings::strToList(Config::sub('redirect', 'nav_show', 'home,latest'));
        if (!$on) {
            $on = array('home', 'latest');
        }
        $h = '';
        foreach ($on as $k) {
            if (!isset($items[$k])) {
                continue;                      // 认不出来的值直接忽略，不报错
            }
            $h .= '<a href="' . self::esc($items[$k][1]) . '">' . self::esc($items[$k][0]) . '</a>';
        }

        /* 自定义外链：一行一个「链接文字|网址」 */
        $ext = (string) Config::sub('redirect', 'nav_external', '');
        if (trim($ext) !== '') {
            foreach (preg_split('/[\r\n]+/', $ext) as $line) {
                $line = trim($line);
                if ($line === '' || strpos($line, '|') === false) {
                    continue;
                }
                $parts = explode('|', $line, 2);
                $txt = trim($parts[0]);
                $url = trim($parts[1]);
                if ($txt === '' || $url === '') {
                    continue;
                }
                $h .= '<a href="' . self::esc($url) . '" target="_blank" rel="noopener nofollow">'
                    . self::esc($txt) . '</a>';
            }
        }
        if ($h === '') {
            return '';
        }
        return '<nav class="mainnav"><div class="navin">' . $h . '</div></nav>';
    }

    /**
     * <body> 的模板类名：前台模板（经典 classic / 简约 simple）
     * + 简约模板的明暗模式（light / dark）。后台「扫描+跳转 → 前端模板」控制。
     */
    public static function bodyClass()
    {
        $tpl = (string) Config::sub('redirect', 'tpl', 'classic');
        if (!in_array($tpl, array('classic', 'simple'), true)) {
            $tpl = 'classic';
        }
        $cls = 'tpl-' . $tpl;
        if ($tpl === 'simple') {
            $mode = (string) Config::sub('redirect', 'simple_mode', 'light');
            $cls .= ($mode === 'dark') ? ' mode-dark' : ' mode-light';
        }
        return $cls;
    }

    /** 页脚：底部介绍 + 声明 + 版权（后台「基础设置」页控制） */
    public static function footerHtml()
    {
        $info = Site::info();
        $h = '<footer class="foot" id="contact"><div class="fin">';
        if ($info['footer_intro'] !== '') {
            $h .= '<p class="fintro">' . Site::text($info['footer_intro']) . '</p>';
        }
        if ($info['declare'] !== '') {
            $h .= '<p class="fdec">声明：' . self::esc($info['declare']) . '</p>';
        }
        if ($info['copyright'] !== '') {
            $h .= '<p class="fcopy">' . Site::text($info['copyright']) . '</p>';
        }
        $h .= '<p class="fbrand">' . self::esc($info['name'])
            . ' · 本站数据整理自公开条目信息</p>';
        $h .= '</div></footer>';
        return $h;
    }

    /** 共享样式（主页与静态内页都内联同一份，保证视觉一致） */
    public static function css()
    {
        return <<<CSS
:root{--bg:#f5f6fa;--card:#fff;--line:#eceef3;--pri:#5b5bd6;--pri2:#8b5cf6;--txt:#1b1f2a;--mut:#9aa1b1;--gold:#f5a524;--clk:#10b981;--hot:#f43f5e;--shadow:0 6px 22px rgba(27,31,42,.06);--shadow-h:0 16px 38px rgba(91,91,214,.18)}
*{box-sizing:border-box}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--txt);line-height:1.65;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
img{max-width:100%}
.topbar{position:sticky;top:0;z-index:30;background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;box-shadow:0 2px 20px rgba(91,91,214,.30)}
.topbar .in{max-width:1180px;margin:0 auto;padding:13px 18px;display:flex;align-items:center;gap:16px}
.brand{font-weight:800;font-size:18px;white-space:nowrap;display:flex;align-items:center;gap:9px;letter-spacing:.3px}
.brand .dot{width:22px;height:22px;border-radius:7px;background:rgba(255,255,255,.22);display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 1px rgba(255,255,255,.35) inset}
.brand .dot:after{content:"";width:9px;height:9px;border-radius:50%;background:#fff}
.search{flex:1;display:flex;gap:8px;max-width:520px;margin-left:auto}
.search input{flex:1;padding:9px 14px;border:0;border-radius:10px;font-size:14px;outline:none;background:rgba(255,255,255,.94);color:var(--txt)}
.search button{padding:9px 18px;border:0;border-radius:10px;background:rgba(255,255,255,.20);color:#fff;cursor:pointer;font-size:14px;transition:background .15s}
.search button:hover{background:rgba(255,255,255,.34)}
.topbar a.admin{color:#fff;opacity:.88;font-size:13px;white-space:nowrap;padding:7px 12px;border-radius:9px;background:rgba(255,255,255,.12);transition:background .15s}
.topbar a.admin:hover{background:rgba(255,255,255,.24)}
/* 首页 banner */
.banner{background:linear-gradient(120deg,#5b5bd6,#8b5cf6 60%,#a855f7);color:#fff;position:relative;overflow:hidden}
.banner:after{content:"";position:absolute;right:-60px;top:-60px;width:260px;height:260px;border-radius:50%;background:rgba(255,255,255,.10)}
.banner:before{content:"";position:absolute;left:-40px;bottom:-90px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.08)}
.banner .in{max-width:1180px;margin:0 auto;padding:34px 18px 30px;position:relative;z-index:1}
.banner h1{margin:0 0 8px;font-size:28px;letter-spacing:.5px}
.banner p{margin:0;opacity:.92;font-size:14.5px}
.banner .badges{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
.banner .badges span{background:rgba(255,255,255,.16);padding:6px 13px;border-radius:20px;font-size:13px}
.wrap{max-width:1180px;margin:22px auto;padding:0 18px}
.toolbar{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}
.sortbtns{display:flex;gap:6px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:5px;box-shadow:var(--shadow)}
.sortbtns a{padding:8px 15px;border-radius:9px;font-size:14px;color:var(--mut);transition:.15s}
.sortbtns a:hover{color:var(--pri)}
.sortbtns a.on{background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;box-shadow:0 6px 16px rgba(91,91,214,.32)}
.filters{display:flex;gap:8px;flex-wrap:wrap}
.filters a{padding:8px 15px;border:1px solid var(--line);background:var(--card);border-radius:20px;font-size:13px;color:var(--mut);transition:.15s}
.filters a:hover{border-color:var(--pri);color:var(--pri)}
.filters a.on{border-color:transparent;background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;font-weight:600}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(164px,1fr));gap:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;overflow:hidden;transition:transform .18s,box-shadow .18s;box-shadow:var(--shadow)}
.card:hover{transform:translateY(-6px);box-shadow:var(--shadow-h)}
.c-thumb{position:relative;aspect-ratio:2/3;background:#eef0f5;overflow:hidden}
.c-thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s}
.card:hover .c-thumb img{transform:scale(1.07)}
.c-noposter{display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:13px;height:100%}
.c-type{position:absolute;left:8px;top:8px;background:rgba(27,31,42,.72);color:#fff;font-size:12px;padding:3px 10px;border-radius:20px}
.c-dl{position:absolute;right:8px;top:8px;background:linear-gradient(120deg,#10b981,#34d399);color:#fff;font-size:11.5px;font-weight:600;padding:3px 9px;border-radius:20px;box-shadow:0 4px 12px rgba(16,185,129,.4)}
.c-body{padding:11px 13px 14px}
.c-title{font-weight:600;font-size:15px;line-height:1.35;max-height:2.7em;overflow:hidden}
.c-sub{color:var(--mut);font-size:12.5px;margin:3px 0 9px}
.c-meta{display:flex;gap:6px;flex-wrap:wrap}
.chip{font-size:12px;padding:3px 9px;border-radius:8px;background:var(--bg);color:var(--mut);white-space:nowrap}
.chip-r{color:var(--gold);background:#fff7e6}
.chip-clk{color:var(--clk);background:#e9f9f1}
.pager{display:flex;gap:10px;align-items:center;justify-content:center;margin:28px 0 10px}
.pager a,.pager span{padding:9px 17px;border:1px solid var(--line);background:var(--card);border-radius:10px;font-size:14px;color:var(--mut);transition:.15s}
.pager a:hover{border-color:var(--pri);color:var(--pri);box-shadow:var(--shadow)}
.empty{color:var(--mut);padding:40px 4px;text-align:center}
.foot{text-align:center;color:var(--mut);font-size:13px;padding:32px 0 44px}
/* ===== 内页 ===== */
.hero{position:relative;min-height:360px;display:flex;align-items:flex-end;color:#fff;overflow:hidden}
.hero .bg{position:absolute;inset:0;background:linear-gradient(135deg,#3a2a5e,#6b3f8f);background-size:cover;background-position:center;transform:scale(1.05)}
.hero .mask{position:absolute;inset:0;background:linear-gradient(180deg,rgba(15,17,26,.20),rgba(15,17,26,.90))}
.hero .in{position:relative;max-width:1180px;margin:0 auto;padding:34px 18px;display:flex;gap:26px;width:100%}
.hero .poster{width:184px;flex:0 0 184px;aspect-ratio:2/3;border-radius:16px;overflow:hidden;background:#222;box-shadow:0 16px 38px rgba(0,0,0,.5);position:relative}
.hero .poster img{width:100%;height:100%;object-fit:cover;display:block}
.hero .poster .np{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#aaa;font-size:13px}
.hero .info{flex:1;min-width:0;padding-bottom:4px}
.hero h1{margin:0 0 8px;font-size:28px;line-height:1.25;letter-spacing:.3px}
.hero .ot{opacity:.82;font-size:14px;margin-bottom:12px}
.hero .tags{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
.hero .tags .t{background:rgba(255,255,255,.16);padding:4px 12px;border-radius:20px;font-size:13px}
.hero .stats{display:flex;gap:10px;flex-wrap:wrap}
.hero .stats .s{background:rgba(255,255,255,.12);padding:8px 15px;border-radius:11px;font-size:13px}
.hero .stats .s b{font-size:16px;margin-left:2px}
.hero .stats .s.gold b{color:#ffcf6b}
.hero .stats .s.clk b{color:#7ef0c0}
.detail{max-width:1180px;margin:24px auto;padding:0 18px;display:grid;grid-template-columns:1fr;gap:22px}
.block{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px 22px;box-shadow:var(--shadow)}
.block h2{margin:0 0 14px;font-size:17px;display:flex;align-items:center;gap:9px}
.block h2:before{content:"";width:4px;height:17px;background:linear-gradient(180deg,var(--pri),var(--pri2));border-radius:3px;display:inline-block}
.ov{color:#3a3f4d;font-size:15px;white-space:pre-wrap}
.dl{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:10px}
.dl li{background:var(--bg);border:1px solid var(--line);border-radius:11px;padding:12px 14px;word-break:break-all;display:flex;gap:11px;align-items:center;transition:.15s}
.dl li:hover{border-color:var(--pri);background:#f7f7ff}
.dl-tag{flex:0 0 auto;background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;font-size:12.5px;font-weight:600;padding:4px 12px;border-radius:20px;white-space:nowrap}
.dl li a{color:var(--pri);font-size:14px;font-weight:600;word-break:break-all}
.dl-raw{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;color:#3a3f4d;white-space:pre-wrap;word-break:break-all}
.block .hint{color:var(--mut);font-size:12px;margin-top:10px}
.kv{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px 18px}
.kv .k{color:var(--mut);font-size:13px}
.kv .v{font-size:14.5px}
.cast{display:flex;gap:14px;overflow-x:auto;padding-bottom:6px}
.cast .p{flex:0 0 110px;text-align:center}
.cast .p img{width:110px;height:150px;object-fit:cover;border-radius:11px;background:#eee}
.cast .p .nm{font-size:13px;margin-top:6px;font-weight:600}
.cast .p .ch{font-size:12px;color:var(--mut)}
.cast .p .p-np{width:110px;height:150px;background:#eee;border-radius:11px;display:flex;align-items:center;justify-content:center;color:#aaa;font-size:12px}
.backbar{max-width:1180px;margin:10px auto 0;padding:0 18px}
.backbar a{display:inline-block;padding:10px 20px;background:linear-gradient(120deg,var(--pri),var(--pri2));color:#fff;border-radius:10px;font-size:14px;box-shadow:0 8px 20px rgba(91,91,214,.3)}
@media(max-width:680px){.hero .in{flex-direction:column}.hero .poster{width:140px;flex:0 0 140px}.hero h1{font-size:22px}.grid{grid-template-columns:repeat(auto-fill,minmax(132px,1fr))}.banner h1{font-size:22px}}
/* ===== 站点设置（LOGO / 站点名 / 宣传语 / 页脚）：后台「站点设置」页控制 ===== */
a.brand{color:#fff}
.brand .logo{width:26px;height:26px;border-radius:7px;object-fit:cover;background:#fff;flex:0 0 26px}
.brand .sname{font-weight:800}
.brand .slogan{font-weight:400;font-size:12.5px;opacity:.86;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.brand .slogan:before{content:"·";margin-right:6px;opacity:.7}
.foot .fin{max-width:1180px;margin:0 auto;padding:0 18px;text-align:left}
.foot .fintro,.foot .fcopy{color:var(--mut);font-size:12.5px;line-height:1.95;margin:0 0 8px}
.foot .fdec{color:#b3b9c6;font-size:12px;line-height:1.95;margin:0 0 8px}
.foot .fbrand{color:var(--mut);font-size:12.5px;text-align:center;padding-top:10px;border-top:1px solid var(--line);margin-top:14px}
@media(max-width:680px){.brand .slogan{display:none}.foot .fin{text-align:center}}
/* ===== 顶部导航 / 前台模板 / 榜单样式 / 最新列表 =====
   全部由后台「站点设置 → 扫描+跳转」控制，未配置时走内置默认。 */
.mainnav{background:rgba(0,0,0,.13);border-top:1px solid rgba(255,255,255,.10)}
.mainnav .navin{max-width:1180px;margin:0 auto;padding:0 18px;display:flex;gap:4px;overflow-x:auto}
.mainnav .navin::-webkit-scrollbar{height:0}
.mainnav a{color:#fff;opacity:.9;font-size:13.5px;padding:9px 13px;border-radius:8px;white-space:nowrap;transition:.15s}
.mainnav a:hover{background:rgba(255,255,255,.16);opacity:1}
/* 全网榜单「无图模式」：卡片变横向纯文字行 */
.grid-plain .card{display:flex;align-items:center;border-radius:12px}
.grid-plain .card:hover{transform:none}
.grid-plain .card .c-thumb{display:none}
.grid-plain .card .c-body{flex:1;min-width:0;padding:13px 16px}
.grid-plain .card .c-title{max-height:none;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
/* 最新更新区块 */
.latest{margin:0 0 22px}
.latest h2{margin:0 0 12px;font-size:16px;display:flex;align-items:center;gap:8px}
.latest h2:before{content:"";width:4px;height:16px;border-radius:2px;background:linear-gradient(120deg,var(--pri),var(--pri2))}
.latest-list{background:var(--card);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow);overflow:hidden}
.latest-list a{display:flex;gap:12px;padding:11px 16px;border-bottom:1px solid var(--line);font-size:14px;transition:.15s}
.latest-list a:last-child{border-bottom:0}
.latest-list a:hover{background:#fafaff;color:var(--pri)}
.latest-list .l-t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.latest-list .l-m{color:var(--mut);font-size:12.5px;white-space:nowrap}
/* 简约模板：更紧凑、去装饰 */
.tpl-simple .banner .in{padding:24px 18px 20px}
.tpl-simple .banner h1{font-size:23px}
.tpl-simple .banner:before,.tpl-simple .banner:after{display:none}
.tpl-simple .sortbtns{box-shadow:none}
.tpl-simple .card{box-shadow:none}
.tpl-simple .block{box-shadow:none}
/* 简约模板 · 暗黑模式 */
.tpl-simple.mode-dark{--bg:#111827;--card:#1b2233;--line:#2b3348;--txt:#e5e9f2;--mut:#98a2b8;--shadow:0 6px 22px rgba(0,0,0,.35)}
.tpl-simple.mode-dark .card:hover{background:#212a3e}
.tpl-simple.mode-dark .filters a{background:var(--card)}
.tpl-simple.mode-dark .latest-list a:hover{background:#212a3e}
.tpl-simple.mode-dark .ov{color:#c3cad8}
.tpl-simple.mode-dark .dl-raw{color:#c3cad8}
.tpl-simple.mode-dark .dl li:hover{background:var(--card)}
CSS;
    }

    /** 主页卡片 */
    public static function cardHtml(array $row)
    {
        $id     = (int) ((isset($row['id']) ? $row['id'] : 0));
        $title  = self::esc((isset($row['title']) ? $row['title'] : '未命名'));
        $year   = !empty($row['year']) ? ('· ' . $row['year']) : '';
        $rating = ($row['rating'] !== null && $row['rating'] !== '') ? number_format((float) $row['rating'], 1) : '—';
        $type   = self::typeLabel((isset($row['type']) ? $row['type'] : ''));
        $poster = (isset($row['poster']) ? $row['poster'] : '');
        $clk    = (int) ((isset($row['clicks']) ? $row['clicks'] : 0));
        $hasDl  = self::hasDownloads((isset($row['download_url']) ? $row['download_url'] : ''));
        $thumb  = $poster
            ? '<img src="' . self::esc($poster) . '" alt="' . self::esc((isset($row['title']) ? $row['title'] : '')) . '" loading="lazy">'
            : '<div class="c-noposter">无封面</div>';
        $dlBadge = $hasDl ? '<span class="c-dl">可下载</span>' : '';
        return <<<HTML
<a class="card" href="/uisc/{$id}.html">
  <div class="c-thumb">{$thumb}<span class="c-type">{$type}</span>{$dlBadge}</div>
  <div class="c-body">
    <div class="c-title">{$title}</div>
    <div class="c-sub">{$type} {$year}</div>
    <div class="c-meta">
      <span class="chip chip-r">★ {$rating}</span>
      <span class="chip chip-clk">点击 {$clk}</span>
    </div>
  </div>
</a>
HTML;
    }

    /** 是否填写了有效下载链接（空则不展示下载相关） */
    public static function hasDownloads($raw)
    {
        foreach (self::parseDownloads($raw) as $l) {
            if (trim((string) ((isset($l['url']) ? $l['url'] : ''))) !== '') { return true; }
        }
        return false;
    }

    /** 主页完整 HTML */
    public static function homeHtml(array $rows,$sort,$type,$page,$total,$q,$perPage,$latest = array())
    {
        $encQ = self::esc($q);
        $sorts = [
            'api_calls'  => '热度',
            'clicks'     => '点击',
            'updated_at' => '最新',
            'rating'     => '评分',
        ];
        $types = ['' => '全部'];
        foreach (Categories::TYPES as $t) { $types[$t] = Categories::label($t); }
        $sortHtml = '';
        foreach ($sorts as $k => $label) {
            $on = $k === $sort ? ' class="on"' : '';
            $sortHtml .= '<a' . $on . ' href="/?sort=' . $k . '&type=' . self::esc($type) . '&q=' . urlencode($q) . '">' . $label . '</a>';
        }
        $filterHtml = '';
        foreach ($types as $k => $label) {
            $on = $k === $type ? ' class="on"' : '';
            $filterHtml .= '<a' . $on . ' href="/?sort=' . self::esc($sort) . '&type=' . $k . '&q=' . urlencode($q) . '">' . $label . '</a>';
        }
        $grid = '';
        foreach ($rows as $r) { $grid .= self::cardHtml($r); }
        if ($grid === '') { $grid = '<p class="empty">暂无资料，去后台添加或触发一次同步吧。</p>'; }

        $totalPages = max(1, (int) ceil($total / $perPage));
        $pager = '';
        if ($totalPages > 1) {
            $prev = $page > 1 ? '<a href="/?sort=' . self::esc($sort) . '&type=' . self::esc($type) . '&q=' . urlencode($q) . '&page=' . ($page - 1) . '">上一页</a>' : '<span>上一页</span>';
            $next = $page < $totalPages ? '<a href="/?sort=' . self::esc($sort) . '&type=' . self::esc($type) . '&q=' . urlencode($q) . '&page=' . ($page + 1) . '">下一页</a>' : '<span>下一页</span>';
            $pager = '<div class="pager">' . $prev . '<span>第 ' . $page . ' / ' . $totalPages . ' 页</span>' . $next . '</div>';
        }

        $sortName = (isset($sorts[$sort]) ? $sorts[$sort] : '点击');
        $typeName = (isset($types[$type]) ? $types[$type] : '全部');
        $totalLbl = number_format($total);
        $info     = Site::info();

        // 无筛选、无搜索、第一页 = 首页，用首页那套 SEO；否则按列表页模板生成
        $isHome   = ($type === '' && $q === '' && (int) $page === 1);
        $headMeta = Site::headMeta($isHome ? 'home' : 'list', array(
            'type_label' => ($type !== '' ? $typeName : ''),
            'sort_label' => $sortName,
            'page'       => $page,
        ));
        $searchForm = '<form class="search" action="/" method="get">'
            . '<input type="hidden" name="sort" value="' . self::esc($sort) . '">'
            . '<input type="hidden" name="type" value="' . self::esc($type) . '">'
            . '<input type="text" name="q" value="' . $encQ . '" placeholder="搜索标题…">'
            . '<button type="submit">搜索</button></form>';
        $topbar = self::topbarHtml($searchForm . '<a class="admin" href="/admin">管理后台</a>');
        $footer = self::footerHtml();
        $bannerTitle = $info['slogan'] !== '' ? self::esc($info['slogan']) : '影视 · 剧集 · 动漫 · 综艺 · 短剧 · 游戏';
        $bannerSub   = '一站式资源资料库，支持在线检索与一键下载。';

        /* 前台模板 / 榜单样式 / 最新更新区块：后台「站点设置 → 扫描+跳转」控制 */
        $bodyClass = self::bodyClass();
        $gridCls   = ((string) Config::sub('redirect', 'rank_style', 'grid') === 'list') ? ' grid-plain' : '';
        $latestHtml = '';
        if (is_array($latest) && $latest && $isHome
            && Site::flag(Config::sub('redirect', 'latest', 1))) {
            $li = '';
            foreach ($latest as $lr) {
                $lid  = (int) ((isset($lr['id']) ? $lr['id'] : 0));
                $lt   = self::esc((isset($lr['title']) ? $lr['title'] : '未命名'));
                $ltp  = self::typeLabel((isset($lr['type']) ? $lr['type'] : ''));
                $ly   = !empty($lr['year']) ? (' · ' . (int) $lr['year']) : '';
                $li  .= '<a href="/uisc/' . $lid . '.html"><span class="l-t">' . $lt . '</span>'
                      . '<span class="l-m">' . $ltp . $ly . '</span></a>';
            }
            if ($li !== '') {
                $latestHtml = '<div class="latest"><h2>最新更新</h2><div class="latest-list">' . $li . '</div></div>';
            }
        }

        $html = <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
{$headMeta}
<style>{CSS_PLACEHOLDER}</style>
</head>
<body class="{$bodyClass}">
{$topbar}

<section class="banner"><div class="in">
  <h1>{$bannerTitle}</h1>
  <p>{$bannerSub}</p>
  <div class="badges">
    <span>共收录 {$totalLbl} 部</span>
    <span>当前分类：{$typeName}</span>
    <span>排序：按{$sortName}</span>
  </div>
</div></section>

<div class="wrap">
  <div class="toolbar">
    <div class="sortbtns">{$sortHtml}</div>
    <div class="filters">{$filterHtml}</div>
  </div>
  {$latestHtml}
  <div class="grid{$gridCls}">{$grid}</div>
  {$pager}
</div>
{$footer}
</body>
</html>
HTML;
        return str_replace('{CSS_PLACEHOLDER}', self::css(), $html);
    }

    /** 内页完整 HTML（静态生成用，按 type/source 分支渲染） */
    public static function renderItemPage(array $row)
    {
        $id     = (int) ((isset($row['id']) ? $row['id'] : 0));
        $type   = (isset($row['type']) ? $row['type'] : '');
        $source = (isset($row['source']) ? $row['source'] : '');
        $title  = self::esc((isset($row['title']) ? $row['title'] : '未命名'));
        $ot     = self::esc((isset($row['original_title']) ? $row['original_title'] : ''));
        $year   = !empty($row['year']) ? (int) $row['year'] : '';
        $rating = ($row['rating'] !== null && $row['rating'] !== '') ? number_format((float) $row['rating'], 1) : '—';
        $typeLb = self::typeLabel($type);
        $poster = (isset($row['poster']) ? $row['poster'] : '');
        $back   = (isset($row['backdrop']) ? $row['backdrop'] : '');
        $clk    = (int) ((isset($row['clicks']) ? $row['clicks'] : 0));
        $genres = [];
        foreach (json_decode((isset($row['genres']) ? $row['genres'] : '[]'), true) ?: [] as $g) { if ($g) $genres[] = self::esc($g); }
        $genresHtml = '';
        if ($genres) {
            foreach ($genres as $g) { $genresHtml .= '<span class="t">' . $g . '</span>'; }
        }

        $bgStyle = $back ? 'style="background-image:url(' . self::esc($back) . ')"' : '';
        $posterHtml = $poster
            ? '<img src="' . self::esc($poster) . '" alt="' . $title . '" loading="lazy">'
            : '<div class="np">无封面</div>';

        $overview = self::esc((isset($row['overview']) ? $row['overview'] : ''));
        $overviewHtml = $overview ? '<div class="block"><h2>简介</h2><div class="ov">' . $overview . '</div></div>' : '';

        // 下载地址块（后台填写；为空不展示）
        $dlHtml = self::downloadBlock($row);

        // 类型相关区块（含 extra 扩展字段）
        $extra = self::extraBlock($row, $source, $type);

        // SEO：标题/关键词/描述按「内页模板 + 条目真实内容」生成（后台「SEO 设置」可改模板）
        $headMeta = Site::headMeta('item', array(
            'id'         => $id,
            'title'      => isset($row['title']) ? (string) $row['title'] : '',
            'type_label' => $typeLb,
            'year'       => ($year !== '' ? (string) $year : ''),
            'overview'   => isset($row['overview']) ? (string) $row['overview'] : '',
            'poster'     => $poster,
        ));
        $topbar = self::topbarHtml('<a class="admin" href="/">← 返回主页</a>');
        $footer = self::footerHtml();
        $bodyClass = self::bodyClass();

        $html = <<<HTML
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
{$headMeta}
<style>{CSS_PLACEHOLDER}</style>
</head>
<body class="{$bodyClass}">
{$topbar}

<section class="hero">
  <div class="bg" {$bgStyle}></div>
  <div class="mask"></div>
  <div class="in">
    <div class="poster">{$posterHtml}</div>
    <div class="info">
      <h1>{$title}</h1>
      <div class="ot">{$ot}</div>
      <div class="tags"><span class="t">{$typeLb}</span>{$genresHtml}</div>
      <div class="stats">
        <span class="s gold">评分<b>{$rating}</b></span>
        <span class="s">年份<b>{$year}</b></span>
        <span class="s clk">点击<b id="m-clicks">{$clk}</b></span>
      </div>
    </div>
  </div>
</section>

<div class="detail">
  {$overviewHtml}
  {$dlHtml}
  {$extra}
</div>

<div class="backbar"><a href="/">← 返回资料库主页</a></div>
{$footer}

<img src="/track?id={$id}&t=click" width="1" height="1" alt="" style="position:absolute;width:1px;height:1px;opacity:0;pointer-events:none">
<script>
(function(){
  var elC=document.getElementById('m-clicks'); if(!elC) return;
  fetch('/api/v1/metric/{$id}').then(function(r){return r.json();}).then(function(d){
    if(d && d.success && d.data){ elC.textContent=d.data.clicks; }
  }).catch(function(){});
})();
</script>
</body>
</html>
HTML;
        return str_replace('{CSS_PLACEHOLDER}', self::css(), $html);
    }

    /** 按来源/类型生成差异化区块（电影剧集=演职员；游戏=平台/厂商；动漫=话数/制作；extra=分类扩展字段） */
    private static function extraBlock(array $row,$source,$type)
    {
        $p = json_decode((isset($row['payload']) ? $row['payload'] : '{}'), true) ?: [];
        $blocks = [];

        if (($source === 'tmdb') && in_array($type, ['movie', 'tv'], true)) {
            $blocks[] = self::castBlock($p);
        }
        if ($source === 'rawg' && $type === 'game') {
            $blocks[] = self::gameBlock($p);
        }
        if ($source === 'bangumi' && $type === 'anime') {
            $blocks[] = self::animeBlock($p);
        }
        if ($type === 'person') {
            $blocks[] = self::personBlock($p, $row);
        }
        // 分类扩展字段（手动新增/后台补充的 集数/导演/平台 等）
        $blocks[] = self::extraFieldsBlock($row);

        return implode('', array_filter($blocks));
    }

    /** 下载地址块：支持多条网盘（JSON 数组 [{label,url}]，兼容旧版纯文本多行），无有效链接则整块隐藏 */
    private static function downloadBlock(array $row)
    {
        $links = self::parseDownloads((isset($row['download_url']) ? $row['download_url'] : ''));
        if (!$links) { return ''; }
        $items = '';
        foreach ($links as $l) {
            $label = self::esc((isset($l['label']) ? $l['label'] : '下载'));
            $url   = trim((string) ((isset($l['url']) ? $l['url'] : '')));
            if ($url === '') { continue; }
            if (preg_match('#^https?://#i', $url)) {
                $items .= '<li><span class="dl-tag">' . $label . '</span><a href="' . self::esc($url) . '" target="_blank" rel="noopener">' . self::esc($url) . '</a></li>';
            } else {
                $items .= '<li><span class="dl-tag">' . $label . '</span><span class="dl-raw">' . self::esc($url) . '</span></li>';
            }
        }
        if ($items === '') { return ''; }
        return '<div class="block"><h2>下载地址</h2><ul class="dl">' . $items . '</ul>'
             . '<p class="hint">如链接失效，请联系站长更新。</p></div>';
    }

    /** 解析下载链接：新格式 JSON 数组 / 旧格式纯文本多行 */
    private static function parseDownloads($raw)
    {
        $raw = trim($raw);
        if ($raw === '') { return []; }
        if (strpos($raw, '[') === 0) {
            $dec = json_decode($raw, true);
            if (is_array($dec)) {
                $out = [];
                foreach ($dec as $e) {
                    if (is_array($e)) {
                        $out[] = ['label' => (isset($e['label']) ? $e['label'] : '下载'), 'url' => (isset($e['url']) ? $e['url'] : '')];
                    } elseif (is_string($e)) {
                        $out[] = ['label' => '下载', 'url' => $e];
                    }
                }
                return $out;
            }
        }
        $lines = array_filter(array_map('trim', preg_split('/\r?\n/', $raw)), function ($x) { return $x !== ''; });
        $out = [];
        foreach ($lines as $x) {
            $out[] = ['label' => '下载', 'url' => $x];
        }
        return $out;
    }

    /** 渲染 media_items.extra(JSON) 中的分类扩展字段 */
    private static function extraFieldsBlock(array $row)
    {
        $ex = json_decode((isset($row['extra']) ? $row['extra'] : '{}'), true);
        if (!is_array($ex) || !$ex) { return ''; }
        $rows = [];
        foreach (Categories::EXTRA_LABELS as $k => $label) {
            if (isset($ex[$k]) && $ex[$k] !== '' && $ex[$k] !== null) {
                $rows[] = ['key' => $label, 'val' => (string) $ex[$k]];
            }
        }
        if (empty($rows)) { return ''; }
        $title = Categories::label((isset($row['type']) ? $row['type'] : '')) . '信息';
        return self::kvBlock($title, $rows);
    }

    private static function castBlock(array $p)
    {
        $cast = (isset($p['credits']['cast']) ? $p['credits']['cast'] : []);
        if (!is_array($cast) || !$cast) { return ''; }
        $cast = array_slice($cast, 0, 14);
        $html = '';
        foreach ($cast as $c) {
            $nm  = self::esc((isset($c['name']) ? $c['name'] : ''));
            $ch  = self::esc((isset($c['character']) ? $c['character'] : ''));
            $pp  = !empty($c['profile_path']) ? 'https://image.tmdb.org/t/p/w185' . $c['profile_path'] : '';
            $img = $pp ? '<img src="' . self::esc($pp) . '" alt="' . $nm . '" loading="lazy">' : '<div class="p-np">无照</div>';
            $html .= '<div class="p">' . $img . '<div class="nm">' . $nm . '</div><div class="ch">' . $ch . '</div></div>';
        }
        return '<div class="block"><h2>主要演职人员</h2><div class="cast">' . $html . '</div></div>';
    }

    private static function gameBlock(array $p)
    {
        $rows = [];
        $plats = [];
        foreach (((isset($p['platforms']) ? $p['platforms'] : [])) as $x) { if (isset($x['platform']['name'])) $plats[] = $x['platform']['name']; }
        $devs = [];
        foreach (((isset($p['developers']) ? $p['developers'] : [])) as $x) { if (isset($x['name'])) $devs[] = $x['name']; }
        $pubs = [];
        foreach (((isset($p['publishers']) ? $p['publishers'] : [])) as $x) { if (isset($x['name'])) $pubs[] = $x['name']; }
        $gens = [];
        foreach (((isset($p['genres']) ? $p['genres'] : [])) as $x) { if (isset($x['name'])) $gens[] = $x['name']; }
        if ($plats) $rows[] = ['key' => '平台', 'val' => implode('、', array_unique($plats))];
        if ($devs)  $rows[] = ['key' => '开发商', 'val' => implode('、', array_unique($devs))];
        if ($pubs)  $rows[] = ['key' => '发行商', 'val' => implode('、', array_unique($pubs))];
        if (!empty($p['released'])) $rows[] = ['key' => '发行日期', 'val' => self::esc($p['released'])];
        if ($gens)  $rows[] = ['key' => '类型', 'val' => implode('、', array_unique($gens))];
        if (empty($rows)) return '';
        return self::kvBlock('游戏信息', $rows);
    }

    private static function animeBlock(array $p)
    {
        $rows = [];
        if (!empty($p['eps']))      $rows[] = ['key' => '话数', 'val' => self::esc($p['eps'])];
        if (!empty($p['air_date']))  $rows[] = ['key' => '开播', 'val' => self::esc($p['air_date'])];
        $studs = [];
        foreach (((isset($p['studios']) ? $p['studios'] : [])) as $x) { if (isset($x['name'])) $studs[] = $x['name']; }
        if ($studs) $rows[] = ['key' => '制作公司', 'val' => implode('、', array_unique($studs))];
        $tags = [];
        foreach (((isset($p['tags']) ? $p['tags'] : [])) as $t) { if (is_array($t)) { $tags[] = (isset($t['name']) ? $t['name'] : ''); } else { $tags[] = $t; } }
        $tags = array_filter(array_slice($tags, 0, 8));
        if ($tags) $rows[] = ['key' => '标签', 'val' => implode('、', $tags)];
        if (empty($rows)) return '';
        return self::kvBlock('番剧信息', $rows);
    }

    private static function personBlock(array $p, array $row)
    {
        $rows = [];
        if (!empty($p['known_for_department'])) $rows[] = ['key' => '职业', 'val' => self::esc($p['known_for_department'])];
        if (!empty($p['birthday']))             $rows[] = ['key' => '出生', 'val' => self::esc($p['birthday'])];
        if (!empty($p['place_of_birth']))       $rows[] = ['key' => '出生地', 'val' => self::esc($p['place_of_birth'])];
        if (empty($rows)) return '';
        return self::kvBlock('人物信息', $rows);
    }

    private static function kvBlock($title, array $rows)
    {
        $html = '';
        foreach ($rows as $r) {
            $html .= '<div><div class="k">' . self::esc($r['key']) . '</div><div class="v">' . self::esc($r['val']) . '</div></div>';
        }
        return '<div class="block"><h2>' . self::esc($title) . '</h2><div class="kv">' . $html . '</div></div>';
    }
}
