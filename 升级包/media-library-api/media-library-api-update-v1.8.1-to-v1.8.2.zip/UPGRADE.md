# media-library-api v1.8.1 -> v1.8.2 升级说明

发布日期：2026-09-23

---

## 这次加了什么

**一句话：配好 SMTP 邮件服务后，忘记密码就能自助重置 —— 后台和前台都支持。**

| 位置 | 新增 |
|---|---|
| 站点设置 / 邮件服务 | SMTP 配置（服务器 / 端口 / 加密 / 账号 / 授权码 / 发件邮箱 / 发件名）+「发送测试邮件」按钮 |
| 后台登录页 | 「忘记密码」：填账号或邮箱，重置链接发进绑定邮箱（60 分钟有效、一次性） |
| 后台右上角 | 「修改密码」：当前密码 + 新密码，可顺带绑定 / 更新邮箱 |
| 前台 | 登录页「忘记密码」；邮件链接落地设置新密码；资源请求页顶栏「修改密码 / 绑邮箱」 |

> 邮箱授权码：QQ / 163 / Gmail 等需要在邮箱设置里生成「授权码」，用它当 SMTP 密码。「发送测试邮件」支持用还没保存的草稿值直接测，失败时会展示 SMTP 会话日志。

---

## 变化文件（11 个）

| 文件 | 变化 |
|---|---|
| `core/Mail.php` | **新增**：零依赖 SMTP 客户端（SSL / STARTTLS / 明文，AUTH LOGIN，中文 HTML 邮件） |
| `core/User.php` | 新增重置表与 changePassword / saveEmail / requestReset / verifyResetToken / doReset |
| `core/Settings.php` | 注册 mail 配置组（9 项） |
| `core/UserViews.php` | 前台新增找回 / 重置 / 修改密码页；登录页加「忘记密码」入口 |
| `api/unified.php` | 新增 `mail_test`、`admin/password` 端点；设置读写收录 mail_* |
| `admin/index.php` | 登录页三视图（登录 / 找回 / 重置）；右上角「修改密码」；设置页「邮件服务」二级页 |
| `user.php` | 新增 /user/forgot、/user/reset、/user/password 三条路由 |
| `index.php` | 版本号 1.8.1 -> 1.8.2 |
| `config/config.sample.php` | 增加 mail 段默认值样例 |
| `安装说明.txt` / `功能说明.txt` | 版本号 + 新功能说明 |

---

## 升级步骤

1. **备份**站点目录（尤其是 `config/config.php`、`config/install.lock`）。
2. 用升级包里的文件**覆盖**站点对应位置（目录结构不变）。
3. `Ctrl+F5` 强刷后台 → 「站点设置 → 邮件服务」填好 SMTP → 点「发送测试邮件」验证。
4. 收到测试邮件即配置成功；此后登录页会出现「忘记密码」。

---

## 不需要做的事

- 不用导任何 SQL —— 新表 `app_password_resets` 在首次使用找回密码时**自动创建**（需数据库账号有建表权限）；
- 不用改 Nginx 伪静态（/user/* 与 /admin 本就走 index.php 路由）；
- 不用动计划任务；
- 不配邮件也不影响现有功能 —— 「忘记密码」页会明确提示未配置，其他一切照旧。

---

## 回滚方法

把上面 11 个文件换回 v1.8.1 的版本即可（`core/Mail.php` 删掉也不影响旧版运行）。
