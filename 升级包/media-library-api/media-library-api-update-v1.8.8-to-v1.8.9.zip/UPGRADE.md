# v1.8.8 → v1.8.9 升级说明

## 新增功能
1. **书籍/音乐类型** - 扩展分类支持 book/music（前后端均已添加）
2. **后台用户中心** - 新增用户管理 tab
3. **图片本地下载** - 自动下载海报/背景图到服务器

## 移除功能
- **删除 Bangumi 适配器** - 移除 Bangumi（动漫，免 key）数据源

## 变更文件
- core/Categories.php - 添加 book/music 类型
- admin/index.php - 添加用户中心 tab + 移除 Bangumi + 添加书籍/音乐分类按钮
- api/unified.php - 添加图片下载逻辑 + 移除 Bangumi
- index.php - 版本号更新到 1.8.9
- __migrate_189.php - 数据库迁移脚本

## 升级步骤
1. 解压覆盖以上文件到线上宝塔站点
2. 浏览器 Ctrl+F5 强刷后台
3. 如需创建用户表，访问 /__migrate_189.php
