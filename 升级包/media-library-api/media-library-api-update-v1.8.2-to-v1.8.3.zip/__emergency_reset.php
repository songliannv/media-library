<?php
/** 紧急重置管理员密码 — 一次性脚本，跑完立刻删掉
 *  用法：
 *  1. 把本文件放到站点根目录
 *  2. 浏览器打开 http://你的域名/__emergency_reset.php
 *  3. 输入你的邮箱和新密码（至少6位）
 *  4. 点「重置」
 *  5. 看到「重置成功」后用新密码登录后台
 *  6. 立刻把本文件删掉
 */
error_reporting(E_ALL); ini_set('display_errors', 1);
header('Content-Type: text/html; charset=utf-8');

$root = __DIR__;
$config_path = $root . '/config/config.php';

if (!file_exists($config_path)) {
    die('<b style="color:red">错误</b>：找不到 config/config.php，站点未安装。<br>请先 /install.php 完成安装。');
}

$c = include $config_path;
$db = $c['db'] ?? [];
if (empty($db['host']) || empty($db['dbname']) || empty($db['user'])) {
    die('<b style="color:red">错误</b>：config.php 数据库段不完整。');
}

$dsn = 'mysql:host=' . $db['host'] . ';port=' . (int)($db['port'] ?? 3306)
     . ';dbname=' . $db['dbname'] . ';charset=utf8mb4';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $newpass = trim($_POST['newpass'] ?? '');
    $newpass2 = trim($_POST['newpass2'] ?? '');

    if ($email === '' || strlen($newpass) < 6 || $newpass !== $newpass2) {
        $error = '邮箱不能空，新密码至少 6 位，且两次必须一致。';
    } else {
        try {
            $pdo = new PDO($dsn, $db['user'], $db['pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            ]);
            // 查账号
            $st = $pdo->prepare("SELECT id, username FROM app_users WHERE email = ? LIMIT 1");
            $st->execute([$email]);
            $row = $st->fetch();
            if (!$row) {
                $error = '找不到这个邮箱对应的账号（请核对是否安装时填的就是这个邮箱）。';
            } else {
                // 重置密码
                $hash = password_hash($newpass, PASSWORD_DEFAULT);
                if ($hash === false) {
                    $error = '密码哈希失败（极端环境），请换台机器生成。';
                } else {
                    $upd = $pdo->prepare("UPDATE app_users SET pass_hash = ? WHERE id = ?");
                    $upd->execute([$hash, $row['id']]);
                    $success = "✓ 已把账号「{$row['username']}」(ID={$row['id']}) 的密码重置为「{$newpass}」。<br>请立即用这个邮箱+密码登录后台，<b style='color:red'>然后删掉本文件</b>。";
                }
            }
        } catch (Exception $e) {
            $error = '数据库错误：' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang=zh>
<head><meta charset=utf-8><title>紧急重置管理员密码</title>
<style>body{font-family:system-ui,sans-serif;max-width:520px;margin:40px auto;padding:0 20px}
input{width:100%;padding:8px;margin:4px 0 12px;box-sizing:border-box}
button{padding:10px 24px;background:#007bff;color:#fff;border:none;cursor:pointer;border-radius:4px}
.ok{color:#15803d;background:#f0fdf4;padding:12px;border-radius:6px;border:1px solid #bbf7d0}
.err{color:#b91c1c;background:#fef2f2;padding:12px;border-radius:6px;border:1px solid #fecaca}
label{font-weight:600;display:block;margin-top:12px}
.warning{color:#b45309;background:#fffbeb;padding:10px;border-radius:6px;border:1px solid #fde68a;margin-bottom:16px}
</style>
</head>
<body>
<h2>🚨 紧急重置管理员密码（v1.8.3）</h2>
<div class="warning">⚠️ 这是临时脚本，重置完成后请立即删除本文件（__emergency_reset.php）。</div>

<?php if ($error): ?><div class="err"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="ok"><?= $success ?></div><?php endif; ?>

<form method=post>
  <label>管理员邮箱（安装时填的那个）</label>
  <input type=email name=email required placeholder="admin@example.com">

  <label>新密码（至少 6 位）</label>
  <input type=password name=newpass required minlength=6>

  <label>确认新密码</label>
  <input type=password name=newpass2 required minlength=6>

  <button type=submit>重置密码</button>
</form>

<p style="margin-top:24px;color:#666;font-size:13px">
后记：如果连邮箱都忘了，去宝塔 → 数据库 → <code>cs_zyfx_wang</code> → <code>app_users</code> 表，看第一条记录的 <code>email</code> 列，把那个值复制过来即可。<br>
如果表里根本没有记录，说明安装没成功，重新跑一遍 <code>/install.php</code>。
</p>
</body>
</html>
