# v1.8.9 → v1.9.0 升级说明

## 新增功能
1. **自动刮削** - 后台新增「自动刮削」tab
   - 自动从 TMDB 补充缺失的海报和背景图
   - 支持按类型筛选（电影/电视剧/动漫等）
   - 可配置每次处理数量（10-500条）
   - 实时显示刮削日志

## 变更文件
- core/CacheStore.php - 添加 autoScrapeImages() 方法
- admin/index.php - 添加自动刮削 tab 和前端交互
- api/unified.php - 添加 handleAutoScrape 方法
- index.php - 版本号更新到 1.9.0

## 升级步骤
1. 解压覆盖以上文件到线上宝塔站点
2. 浏览器 Ctrl+F5 强刷后台
3. 打开后台 → 自动刮削 tab
4. 选择类型和数量，点击「开始刮削」

## 注意事项
- 刮削频率受 TMDB API 限制（每条间隔 200ms）
- 仅处理 poster 或 backdrop 为空的条目
- 非 TMDB 来源的条目会跳过
