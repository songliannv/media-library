<?php
/**
 * 媒资资料库 · 命令行安装器（tools/install-cli.php）
 * ==================================================================
 * 为什么不再提供网页版安装器：
 *   网页版 install.php 挂在公网上，任何人只要访问到它，就能重装你的站点、
 *   或者从它的环境自检里读到服务器信息。所以从 v1.4.0 起**彻底移除**了它，
 *   安装改为只能在服务器终端里执行的本脚本 —— 公网访问本文件一律 404。
 *
 * 用法（宝塔 → 终端，先 cd 到站点根目录）：
 *   php tools/install-cli.php
 *       交互式，逐步输入数据库信息（推荐）
 *
 *   php tools/install-cli.php --db=media_library --user=media_lib --pass=xxxx
 *       参数式，适合脚本/批量部署
 *
 *   常用附加参数：
 *     --host=127.0.0.1   数据库地址（默认 127.0.0.1）
 *     --port=3306        端口（默认 3306）
 *     --token=xxx        后台管理令牌（不填会自动生成一个随机令牌）
 *     --tmdb=xxx         TMDB API Key（可留空，装完也能在后台改）
 *     --rawg=xxx         RAWG API Key（可留空）
 *     --force            已安装过也强制重装（会先备份原 config.php）
 *     --yes              全部用默认值/参数值，不交互
 *
 * 本脚本会：测试数据库 → 自动建表（已存在则跳过）→ 生成 config/config.php
 *          与 config/pan_types.php（写前自动备份）→ 写 config/install.lock。
 *
 * 兼容 PHP 5.6 ~ 8.2。公网不可访问：非命令行运行会直接返回 404。
 */

/* ---------------- 只允许命令行运行 ---------------- */
if (php_sapi_name() !== 'cli') {
    require_once __DIR__ . '/../core/Guard.php';
    ml_guard_deny();
}

require_once __DIR__ . '/../core/Guard.php';
require_once __DIR__ . '/../core/InstallGuard.php';

$ROOT      = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/');
$CFG_FILE  = $ROOT . '/config/config.php';
$PAN_FILE  = $ROOT . '/config/pan_types.php';
$LOCK_FILE = $ROOT . '/config/install.lock';

/* ================================================================== */
/* 小工具                                                             */
/* ================================================================== */

function cli_out($s = '')
{
    fwrite(STDOUT, $s . "\n");
}

function cli_err($s)
{
    fwrite(STDERR, $s . "\n");
}

function cli_ask($label, $default = '')
{
    $tip = $default === '' ? ' : ' : ' [' . $default . '] : ';
    fwrite(STDOUT, $label . $tip);
    $line = fgets(STDIN);
    if ($line === false) {
        return $default;
    }
    $line = trim($line);
    return $line === '' ? $default : $line;
}

/** 生成随机令牌（PHP 5.6 可用，不依赖 random_bytes） */
function cli_rand_token()
{
    return substr(md5(uniqid('ml', true)), 0, 16);
}

function cli_q($v)
{
    return "'" . str_replace(array('\\', "'"), array('\\\\', "\\'"), (string) $v) . "'";
}

/** 建表 SQL（与 sql/install.sql 一致，此处内嵌以免依赖文件读取权限） */
function cli_sql()
{
    return array(
        "CREATE TABLE IF NOT EXISTS media_items (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  source        VARCHAR(32)  NOT NULL DEFAULT '',
  source_id     VARCHAR(64)  NOT NULL DEFAULT '',
  type          VARCHAR(32)  NOT NULL DEFAULT '',
  title         VARCHAR(512) NOT NULL DEFAULT '',
  original_title VARCHAR(512) NOT NULL DEFAULT '',
  year          SMALLINT     DEFAULT NULL,
  rating        DECIMAL(6,2) DEFAULT NULL,
  vote_count    INT          DEFAULT NULL,
  api_calls     INT UNSIGNED NOT NULL DEFAULT 0,
  clicks        INT UNSIGNED NOT NULL DEFAULT 0,
  genres        TEXT,
  poster        VARCHAR(1024) NOT NULL DEFAULT '',
  backdrop      VARCHAR(1024) NOT NULL DEFAULT '',
  overview      TEXT,
  download_url  MEDIUMTEXT   NULL,
  extra         TEXT,
  payload       MEDIUMTEXT,
  cached_at     DATETIME     DEFAULT NULL,
  refresh_at    DATETIME     DEFAULT NULL,
  updated_at    DATETIME     DEFAULT NULL,
  UNIQUE KEY uq_src (source, source_id, type),
  KEY idx_type (type),
  KEY idx_title (title(191)),
  KEY idx_year (year),
  KEY idx_rating (rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS sync_log (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  task       VARCHAR(64) NOT NULL DEFAULT '',
  detail     TEXT,
  items      INT DEFAULT 0,
  created_at DATETIME DEFAULT NULL,
  KEY idx_task (task)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS link_checks (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  item_id    INT UNSIGNED NOT NULL,
  label      VARCHAR(64)  NOT NULL DEFAULT '',
  url        VARCHAR(2048) NOT NULL DEFAULT '',
  status     TINYINT NOT NULL DEFAULT 0,
  http_code  SMALLINT NOT NULL DEFAULT 0,
  checked_at DATETIME DEFAULT NULL,
  KEY idx_item (item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

        "CREATE TABLE IF NOT EXISTS app_settings (
  `k`          VARCHAR(64) NOT NULL,
  `v`          TEXT,
  `updated_at` DATETIME DEFAULT NULL,
  PRIMARY KEY (`k`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    );
}

/** 生成 config/config.php 内容 */
function cli_config_content($db, $tmdbKey, $rawgKey, $adminToken, $adapters)
{
    $t  = "\n    ";
    $s  = "<?php\n";
    $s .= "/**\n * 媒资资料库 API - 配置文件（由命令行安装器自动生成 " . date('Y-m-d H:i:s') . "）\n";
    $s .= " * 如需改动数据库/密钥，直接改本文件即可；也可在后台「系统设置」里改（优先级更高）。\n */\n\n";
    /* 生成的配置也必须带"反直接访问"守卫：否则 /config/config.php 会被
       PHP 直接执行（返回 200），把内部文件的存在与路径暴露出去。 */
    $s .= "/* 安全守卫：本文件只应被入口（index.php / check.php / cron）引入；\n";
    $s .= "   直接被网址请求时返回 404 —— 见 core/Guard.php。 */\n";
    $s .= "if (is_file(__DIR__ . '/../core/Guard.php')) {\n";
    $s .= "    require_once __DIR__ . '/../core/Guard.php';\n";
    $s .= "    if (function_exists('ml_guard_shield')) { ml_guard_shield(__FILE__); }\n";
    $s .= "}\n\n";
    $s .= "return [\n";
    $s .= $t . "// 数据库（宝塔新建的 MySQL 库）\n";
    $s .= $t . "'db' => [\n";
    $s .= $t . "    'host'     => " . cli_q($db['host']) . ",\n";
    $s .= $t . "    'port'     => " . (int) $db['port'] . ",\n";
    $s .= $t . "    'dbname'   => " . cli_q($db['dbname']) . ",\n";
    $s .= $t . "    'user'     => " . cli_q($db['user']) . ",\n";
    $s .= $t . "    'pass'     => " . cli_q($db['pass']) . ",\n";
    $s .= $t . "    'charset'  => 'utf8mb4',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// TMDB（影视/人物） https://www.themoviedb.org/settings/api 申请\n";
    $s .= $t . "'tmdb' => [\n";
    $s .= $t . "    'api_key'   => " . cli_q($tmdbKey) . ",\n";
    $s .= $t . "    'base'      => 'https://api.themoviedb.org/3',\n";
    $s .= $t . "    'image_base'=> 'https://image.tmdb.org/t/p/',\n";
    $s .= $t . "    'lang'      => 'zh-CN',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// RAWG（游戏） https://rawg.io/apidocs 申请\n";
    $s .= $t . "'rawg' => [\n";
    $s .= $t . "    'api_key'   => " . cli_q($rawgKey) . ",\n";
    $s .= $t . "    'base'      => 'https://rawg.io/api',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// Bangumi（动漫） https://bangumi.github.io/api/\n";
    $s .= $t . "'bangumi' => [\n";
    $s .= $t . "    'base'      => 'https://api.bgm.tv',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 启用的数据源适配器\n";
    $s .= $t . "'adapters' => [" . cli_q($adapters[0])
        . ($adapters[1] !== '' ? ", " . cli_q($adapters[1]) : '')
        . ($adapters[2] !== '' ? ", " . cli_q($adapters[2]) : '') . "],\n\n";
    $s .= $t . "// 缓存策略\n";
    $s .= $t . "'cache' => [\n";
    $s .= $t . "    'ttl_days'   => 7,\n";
    $s .= $t . "    'stale_days' => 30,\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// TMDB 兼容代理是否强制校验 key（默认 false，ZBLOK 改 base URL 即用）\n";
    $s .= $t . "'proxy' => [\n";
    $s .= $t . "    'require_key' => false,\n";
    $s .= $t . "    'proxy_key'   => '',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 后台管理 token（请求头 X-Admin-Token 或 ?token=）\n";
    $s .= $t . "'admin' => [\n";
    $s .= $t . "    'token' => " . cli_q($adminToken) . ",\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// ================= 站点设置（v1.6.0 起；建议都到后台「站点设置」里改） =================\n";
    $s .= $t . "'site' => [\n";
    $s .= $t . "    'name'      => '媒资资料库', 'name_hide' => 0, 'slogan' => '',\n";
    $s .= $t . "    'logo'      => '', 'favicon' => '', 'url' => '',\n";
    $s .= $t . "    'footer_intro' => '', 'declare' => '', 'copyright' => '',\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// SEO：首页三件套 + 标题模板 + 统计代码 + robots / sitemap\n";
    $s .= $t . "'seo' => [\n";
    $s .= $t . "    'title' => '', 'keywords' => '', 'description' => '', 'stats_code' => '',\n";
    $s .= $t . "    'pattern_type' => '{type} - 第{page}页 - {site}',\n";
    $s .= $t . "    'pattern_item' => '{title}({year}) - {type} - {site}',\n";
    $s .= $t . "    'item_desc_len' => 0, 'robots' => '', 'sitemap' => 1, 'sitemap_size' => 5000,\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 跳转与扫码 + 前台模板（target 与 qr 都为空 = 不拦截访客）\n";
    $s .= $t . "'redirect' => [\n";
    $s .= $t . "    'mode' => 'jump_scan', 'target' => '', 'mobile' => 0, 'qr' => '', 'qr_tip' => '',\n";
    $s .= $t . "    'tpl' => 'classic', 'simple_mode' => 'auto', 'nav_show' => 'home,latest',\n";
    $s .= $t . "    'nav_external' => '', 'rank_style' => 'grid', 'latest' => 1,\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 网盘账号（后台「站点设置 → 网盘链接」；只保存与检测，不会登录你的网盘）\n";
    $s .= $t . "'pan' => [\n";
    $s .= $t . "    'group' => 'quark,aliyun,baidu,uc,xunlei,guangya',\n";
    $s .= $t . "    // 'quark_cookie' => '', 'quark_dir' => '', 'quark_tmp' => '',  // 其余同理\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 接口配置：PanSou 网盘搜索（采集后自动补网盘下载地址）\n";
    $s .= $t . "'pansou' => [\n";
    $s .= $t . "    'enable' => 0, 'mode' => 'local', 'url' => 'http://127.0.0.1:8888',\n";
    $s .= $t . "    'user' => '', 'pass' => '', 'line' => 'PanSou 主线路', 'types' => '',\n";
    $s .= $t . "    'auto' => 1, 'policy' => 'exact', 'match' => 80, 'max' => 5,\n";
    $s .= $t . "    'delay' => 1000, 'ttl' => 720,\n";
    $s .= $t . "],\n\n";
    $s .= $t . "// 资源请求（注册 + 求片区）；两张表由程序首次使用时自动创建\n";
    $s .= $t . "'req' => [\n";
    $s .= $t . "    'open' => 1, 'logon' => 1, 'audit' => 0, 'verify' => 1,\n";
    $s .= $t . "    'guest_view' => 1, 'public' => 1, 'contact' => 1, 'nav' => 1,\n";
    $s .= $t . "    'daily' => 5, 'mintitle' => 2,\n";
    $s .= $t . "    'page_title' => '资源请求', 'page_intro' => '', 'notice' => '',\n";
    $s .= $t . "],\n";
    $s .= "];\n";
    return $s;
}

function cli_pan_content($list)
{
    $lines = array();
    foreach ($list as $x) {
        $lines[] = "    '" . str_replace(array('\\', "'"), array('\\\\', "\\'"), $x) . "',";
    }
    return "<?php\n/**\n * 网盘类型（后台「下载链接」下拉用）\n * 新增网盘只改本文件即可；升级包覆盖本文件也不会影响数据库与密钥配置。\n */\n\n"
        . "/* 安全守卫：本文件只应被入口引入；直接被网址请求时返回 404 —— 见 core/Guard.php。 */\n"
        . "if (is_file(__DIR__ . '/../core/Guard.php')) {\n"
        . "    require_once __DIR__ . '/../core/Guard.php';\n"
        . "    if (function_exists('ml_guard_shield')) { ml_guard_shield(__FILE__); }\n"
        . "}\n\n"
        . "return [\n"
        . implode("\n", $lines) . "\n];\n";
}

/** 写文件（先备份，失败返回 false） */
function cli_write($file, $content)
{
    $dir = dirname($file);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (file_exists($file)) {
        @copy($file, $file . '.bak-' . date('Ymd-His'));
    }
    $ok = @file_put_contents($file, $content) !== false;
    return $ok;
}

/* ================================================================== */
/* 解析参数                                                           */
/* ================================================================== */

$ARGS = array();
foreach (array_slice($argv, 1) as $a) {
    if (strpos($a, '--') === 0) {
        $p  = substr($a, 2);
        $eq = strpos($p, '=');
        if ($eq === false) {
            $ARGS[$p] = true;
        } else {
            $ARGS[substr($p, 0, $eq)] = substr($p, $eq + 1);
        }
    }
}
$FORCE = !empty($ARGS['force']);
$YES   = !empty($ARGS['yes']);

function cli_arg($ARGS, $k, $d = '')
{
    return (isset($ARGS[$k]) && $ARGS[$k] !== true) ? (string) $ARGS[$k] : $d;
}

/* ================================================================== */
/* 开场                                                               */
/* ================================================================== */

cli_out('');
cli_out('=====================================================');
cli_out('  媒资资料库 · 命令行安装器  (tools/install-cli.php)');
cli_out('=====================================================');
cli_out('');

/* ---------------- 环境检查 ---------------- */
$phpOk = version_compare(PHP_VERSION, '5.6.0', '>=');
if (!$phpOk) {
    cli_err('[×] PHP 版本过低：' . PHP_VERSION . '，需要 5.6 及以上。');
    exit(1);
}
foreach (array('pdo_mysql', 'curl', 'json') as $ext) {
    if (!extension_loaded($ext)) {
        cli_err('[×] 缺少 PHP 扩展：' . $ext . '（宝塔 → 网站 → 设置 → PHP → 安装扩展）');
        exit(1);
    }
}
cli_out('[√] PHP ' . PHP_VERSION . '，pdo_mysql / curl / json 扩展齐全');

$cfgDir = $ROOT . '/config';
if (!is_dir($cfgDir)) {
    @mkdir($cfgDir, 0755, true);
}
if (!is_writable($cfgDir)) {
    cli_err('[×] 目录不可写：' . $cfgDir . '（宝塔里给站点目录 755 属主 www）');
    exit(1);
}
cli_out('[√] config/ 目录可写');

/* ---------------- 已安装判断 ---------------- */
$state = ml_install_state($ROOT);
if (!empty($state['installed']) && !$FORCE) {
    cli_out('');
    cli_out('[!] 检测到本站**已经安装过**（原因：' . $state['reason'] . '）。');
    cli_out('    如果只是想改数据库或密钥，直接改 config/config.php 或在后台「系统设置」里改即可。');
    cli_out('    确实要重装（会覆盖配置，原文件自动备份为 config.php.bak-日期）：');
    cli_out('        php tools/install-cli.php --force');
    cli_out('');
    exit(0);
}

/* ---------------- 采集参数 ---------------- */
cli_out('');
if ($YES) {
    $in = array(
        'host'  => cli_arg($ARGS, 'host', '127.0.0.1'),
        'port'  => cli_arg($ARGS, 'port', '3306'),
        'db'    => cli_arg($ARGS, 'db', ''),
        'user'  => cli_arg($ARGS, 'user', ''),
        'pass'  => cli_arg($ARGS, 'pass', ''),
        'token' => cli_arg($ARGS, 'token', ''),
        'tmdb'  => cli_arg($ARGS, 'tmdb', ''),
        'rawg'  => cli_arg($ARGS, 'rawg', ''),
    );
    if ($in['db'] === '' || $in['user'] === '') {
        cli_err('[×] --yes 模式下必须提供 --db= 与 --user=');
        exit(1);
    }
} else {
    cli_out('请填写数据库信息（直接回车用括号里的默认值）：');
    cli_out('');
    $in = array(
        'host'  => cli_ask('数据库地址        ', cli_arg($ARGS, 'host', '127.0.0.1')),
        'port'  => cli_ask('数据库端口        ', cli_arg($ARGS, 'port', '3306')),
        'db'    => cli_ask('数据库名 dbname   ', cli_arg($ARGS, 'db', '')),
        'user'  => cli_ask('数据库用户名      ', cli_arg($ARGS, 'user', '')),
        'pass'  => cli_ask('数据库密码        ', cli_arg($ARGS, 'pass', '')),
        'token' => cli_ask('后台管理令牌(可空)', cli_arg($ARGS, 'token', '')),
        'tmdb'  => cli_ask('TMDB Key (可空)   ', cli_arg($ARGS, 'tmdb', '')),
        'rawg'  => cli_ask('RAWG Key (可空)   ', cli_arg($ARGS, 'rawg', '')),
    );
}
cli_out('');

if ($in['db'] === '' || $in['user'] === '') {
    cli_err('[×] 数据库名与用户名不能为空。');
    exit(1);
}
if ($in['token'] === '') {
    $in['token'] = cli_rand_token();
    cli_out('[i] 未填后台令牌，已自动生成：' . $in['token']);
    cli_out('    （请记下它；也可以之后在后台「系统设置」里改）');
}
if (strlen($in['token']) < 6) {
    cli_err('[×] 后台令牌太短，请至少 6 位。');
    exit(1);
}

/* ---------------- 测试数据库 ---------------- */
cli_out('[..] 正在连接数据库…');
$dsn = 'mysql:host=' . $in['host'] . ';port=' . (int) $in['port'] . ';dbname=' . $in['db'] . ';charset=utf8mb4';
try {
    $pdo = new PDO($dsn, $in['user'], $in['pass'], array(
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT            => 6,
    ));
} catch (Exception $e) {
    cli_err('[×] 连接失败：' . $e->getMessage());
    cli_err('');
    cli_err('    常见原因：');
    cli_err('      · 数据库名/用户名/密码写错（宝塔 → 数据库 里可改密码）');
    cli_err('      · 数据库还没建（先在宝塔建库）');
    cli_err('      · MySQL 8 + PHP 5.6 的 caching_sha2_password 认证不兼容：');
    cli_err('        在宝塔 → 数据库 → 该库用户 → 改密码时选 mysql_native_password');
    exit(1);
}
$ver = (string) $pdo->query('SELECT VERSION()')->fetchColumn();
cli_out('[√] 数据库连接成功，MySQL ' . $ver);

/* ---------------- 建表 ---------------- */
cli_out('[..] 正在建表…');
try {
    foreach (cli_sql() as $sql) {
        $pdo->exec($sql);
    }
} catch (Exception $e) {
    cli_err('[×] 建表失败：' . $e->getMessage());
    exit(1);
}
cli_out('[√] 表结构就绪：media_items / sync_log / link_checks / app_settings');

/* ---------------- 生成配置 ---------------- */
$dbCfg = array(
    'host'   => $in['host'],
    'port'   => (int) $in['port'],
    'dbname' => $in['db'],
    'user'   => $in['user'],
    'pass'   => $in['pass'],
);

$adapters = array('tmdb', 'rawg', 'bangumi');
$panList  = array('夸克', '迅雷', '光鸭', '百度', 'UC');

if (!cli_write($CFG_FILE, cli_config_content($dbCfg, $in['tmdb'], $in['rawg'], $in['token'], $adapters))) {
    cli_err('[×] 写入 config/config.php 失败（检查 config/ 目录权限）');
    exit(1);
}
cli_out('[√] 已生成 ' . $CFG_FILE);
cli_out('    ↳ 后台管理令牌：' . $in['token']);

if (!file_exists($PAN_FILE)) {
    @cli_write($PAN_FILE, cli_pan_content($panList));
    cli_out('[√] 已生成 ' . $PAN_FILE . '（默认：' . implode(' / ', $panList) . '）');
} else {
    cli_out('[i] ' . $PAN_FILE . ' 已存在，保持不变');
}

if (!file_exists($LOCK_FILE)) {
    @file_put_contents($LOCK_FILE, "installed at " . date('c') . "\n");
}
@file_put_contents($ROOT . '/install-info.txt',
    "安装时间: " . date('Y-m-d H:i:s') . "\n"
    . "站点目录: " . $ROOT . "\n"
    . "后台管理员令牌: " . $in['token'] . "\n"
    . "※ 本文件包含敏感信息，请勿长期留在站点目录；记下令牌后可直接删除。\n");
cli_out('[√] 已写 config/install.lock（锁定安装）');

/* ---------------- 收尾 ---------------- */
cli_out('');
cli_out('=====================================================');
cli_out('  安装完成 ✅');
cli_out('=====================================================');
cli_out('  后台入口：  https://你的域名/admin');
cli_out('  （后台管理 Token 就是上面那个令牌）');
cli_out('');
cli_out('  自检报告：  https://你的域名/check.php?token=' . $in['token']);
cli_out('');
cli_out('  下一步建议：');
cli_out('   1) 打开后台 → 系统设置，填 TMDB / RAWG Key 与要用的网盘类型；');
cli_out('   2) 后台 → 同步热门，采集一批数据；');
cli_out('   3) 宝塔 → 网站 → 伪静态，确认已填入（必须）：');
cli_out('        location / { try_files $uri $uri/ /index.php?$query_string; }');
cli_out('     并按 DEPLOY.md「安全加固」一节加上目录保护规则；');
cli_out('   4) 确认自检全部正常后，可删掉 check.php（或改名）与 install-info.txt。');
cli_out('');
cli_out('  提示：网页版安装器 install.php 已移除，本站无法被他人通过网址重装。');
cli_out('');
exit(0);
